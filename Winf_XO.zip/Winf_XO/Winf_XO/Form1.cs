﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Winf_XO
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            szamolas.Text = "0";


        }

        public void Form1_Load(object sender, EventArgs e)
        {



        }

        public void label1_Click_1(object sender, EventArgs e)
        {
            string X_O;
            int k = Convert.ToInt32(szamolas.Text);
            if (k % 2 == 0) { X_O = "X"; }
            else { X_O = "O"; }
            if (label1.Text == "+")
            {
                k++;
                szamolas.Text = k.ToString();
                label1.Text = X_O;
            }
            else { MessageBox.Show("Rosz helyre click-eltél"); }
        }


        private void label2_Click(object sender, EventArgs e)
        {

            string X_O;
            int k = Convert.ToInt32(szamolas.Text);
            if (k % 2 == 0) { X_O = "X"; }
            else { X_O = "O"; }
            if (label2.Text == "+")
            {
                k++;
                szamolas.Text = k.ToString();
                label2.Text = X_O;
            }
            else { MessageBox.Show("Rosz helyre click-eltél"); }


        }

        private void label3_Click_1(object sender, EventArgs e)
        {

            string X_O;
            int k = Convert.ToInt32(szamolas.Text);
            if (k % 2 == 0) { X_O = "X"; }
            else { X_O = "O"; }
            if (label3.Text == "+")
            {
                k++;
                szamolas.Text = k.ToString();
                label3.Text = X_O;
            }
            else { MessageBox.Show("Rosz helyre click-eltél"); }

        }

        private void label4_Click(object sender, EventArgs e)
        {

            string X_O;
            int k = Convert.ToInt32(szamolas.Text);
            if (k % 2 == 0) { X_O = "X"; }
            else { X_O = "O"; }
            if (label4.Text == "+")
            {
                k++;
                szamolas.Text = k.ToString();
                label4.Text = X_O;
            }
            else { MessageBox.Show("Rosz helyre click-eltél"); }
        }

        private void label5_Click(object sender, EventArgs e)
        {

            string X_O;
            int k = Convert.ToInt32(szamolas.Text);
            if (k % 2 == 0) { X_O = "X"; }
            else { X_O = "O"; }
            if (label5.Text == "+")
            {
                k++;
                szamolas.Text = k.ToString();
                label5.Text = X_O;
            }
            else { MessageBox.Show("Rosz helyre click-eltél"); }
        }

        private void label6_Click(object sender, EventArgs e)
        {

            string X_O;
            int k = Convert.ToInt32(szamolas.Text);
            if (k % 2 == 0) { X_O = "X"; }
            else { X_O = "O"; }
            if (label6.Text == "+")
            {
                k++;
                szamolas.Text = k.ToString();
                label6.Text = X_O;
            }
            else { MessageBox.Show("Rosz helyre click-eltél"); }
        }

        private void label7_Click(object sender, EventArgs e)
        {
            string X_O;
            int k = Convert.ToInt32(szamolas.Text);
            if (k % 2 == 0) { X_O = "X"; }
            else { X_O = "O"; }
            if (label7.Text == "+")
            {
                k++;
                szamolas.Text = k.ToString();
                label7.Text = X_O;
            }
            else { MessageBox.Show("Rosz helyre click-eltél"); }

        }

        private void label8_Click(object sender, EventArgs e)
        {
            string X_O;
            int k = Convert.ToInt32(szamolas.Text);
            if (k % 2 == 0) { X_O = "X"; }
            else { X_O = "O"; }
            if (label8.Text == "+")
            {
                k++;
                szamolas.Text = k.ToString();
                label8.Text = X_O;
            }
            else { MessageBox.Show("Rosz helyre click-eltél"); }

        }

        private void label9_Click(object sender, EventArgs e)
        {
            string X_O;
            int k = Convert.ToInt32(szamolas.Text);
            if (k % 2 == 0) { X_O = "X"; }
            else { X_O = "O"; }
            if (label9.Text == "+")
            {
                k++;
                szamolas.Text = k.ToString();
                label9.Text = X_O;
            }
            else { MessageBox.Show("Rosz helyre click-eltél"); }
        }

       
    }
}
