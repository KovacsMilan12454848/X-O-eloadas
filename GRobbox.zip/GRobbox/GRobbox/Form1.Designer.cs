﻿namespace GRobbox
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Cim = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.O = new System.Windows.Forms.Label();
            this.X = new System.Windows.Forms.Label();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.kezolap = new System.Windows.Forms.GroupBox();
            this.EmbxEmb_3x3 = new System.Windows.Forms.GroupBox();
            this.gyozteslab1 = new System.Windows.Forms.Label();
            this.menub1 = new System.Windows.Forms.Button();
            this.restartb1 = new System.Windows.Forms.Button();
            this.Player1_3x3_E = new System.Windows.Forms.Label();
            this.Player2_3x3_E = new System.Windows.Forms.Label();
            this.O_p1 = new System.Windows.Forms.Label();
            this.X_P1 = new System.Windows.Forms.Label();
            this.progressBar4 = new System.Windows.Forms.ProgressBar();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.progressBar3 = new System.Windows.Forms.ProgressBar();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.progressBar2 = new System.Windows.Forms.ProgressBar();
            this.EmbxEmb_5x5 = new System.Windows.Forms.GroupBox();
            this.gyozteslab2 = new System.Windows.Forms.Label();
            this.menub2 = new System.Windows.Forms.Button();
            this.restartb2 = new System.Windows.Forms.Button();
            this.progressBar9 = new System.Windows.Forms.ProgressBar();
            this.progressBar8 = new System.Windows.Forms.ProgressBar();
            this.progressBar7 = new System.Windows.Forms.ProgressBar();
            this.progressBar6 = new System.Windows.Forms.ProgressBar();
            this.progressBar5 = new System.Windows.Forms.ProgressBar();
            this.progressBar10 = new System.Windows.Forms.ProgressBar();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.progressBar11 = new System.Windows.Forms.ProgressBar();
            this.progressBar12 = new System.Windows.Forms.ProgressBar();
            this.Player1_5x5_E = new System.Windows.Forms.Label();
            this.Player2_5x5_E = new System.Windows.Forms.Label();
            this.O_P2 = new System.Windows.Forms.Label();
            this.X_P2 = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.kezolap.SuspendLayout();
            this.EmbxEmb_3x3.SuspendLayout();
            this.EmbxEmb_5x5.SuspendLayout();
            this.SuspendLayout();
            // 
            // Cim
            // 
            this.Cim.AutoSize = true;
            this.Cim.Font = new System.Drawing.Font("Microsoft YaHei", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Cim.ForeColor = System.Drawing.Color.White;
            this.Cim.Location = new System.Drawing.Point(435, 147);
            this.Cim.Name = "Cim";
            this.Cim.Size = new System.Drawing.Size(323, 66);
            this.Cim.TabIndex = 46;
            this.Cim.Text = "Tic-Tac-Toe";
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button2.Location = new System.Drawing.Point(259, 515);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(669, 71);
            this.button2.TabIndex = 41;
            this.button2.Text = "Start";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button1.Location = new System.Drawing.Point(259, 420);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(669, 52);
            this.button1.TabIndex = 40;
            this.button1.Text = "History";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft YaHei", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox2.Location = new System.Drawing.Point(312, 342);
            this.textBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(249, 38);
            this.textBox2.TabIndex = 39;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft YaHei", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox1.Location = new System.Drawing.Point(312, 270);
            this.textBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(249, 38);
            this.textBox1.TabIndex = 38;
            // 
            // O
            // 
            this.O.AutoSize = true;
            this.O.Font = new System.Drawing.Font("Microsoft YaHei", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.O.ForeColor = System.Drawing.Color.White;
            this.O.Location = new System.Drawing.Point(251, 335);
            this.O.Name = "O";
            this.O.Size = new System.Drawing.Size(46, 44);
            this.O.TabIndex = 37;
            this.O.Text = "O";
            // 
            // X
            // 
            this.X.AutoSize = true;
            this.X.Font = new System.Drawing.Font("Microsoft YaHei", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.X.ForeColor = System.Drawing.Color.White;
            this.X.Location = new System.Drawing.Point(251, 263);
            this.X.Name = "X";
            this.X.Size = new System.Drawing.Size(42, 44);
            this.X.TabIndex = 36;
            this.X.Text = "X";
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.radioButton2.ForeColor = System.Drawing.Color.White;
            this.radioButton2.Location = new System.Drawing.Point(20, 69);
            this.radioButton2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(60, 27);
            this.radioButton2.TabIndex = 45;
            this.radioButton2.Text = "5x5";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.radioButton1.ForeColor = System.Drawing.Color.White;
            this.radioButton1.Location = new System.Drawing.Point(20, 21);
            this.radioButton1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(60, 27);
            this.radioButton1.TabIndex = 44;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "3x3";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioButton3);
            this.groupBox2.Controls.Add(this.radioButton4);
            this.groupBox2.Location = new System.Drawing.Point(821, 255);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Size = new System.Drawing.Size(108, 126);
            this.groupBox2.TabIndex = 49;
            this.groupBox2.TabStop = false;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.radioButton3.ForeColor = System.Drawing.Color.White;
            this.radioButton3.Location = new System.Drawing.Point(11, 70);
            this.radioButton3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(65, 27);
            this.radioButton3.TabIndex = 45;
            this.radioButton3.Text = "Gép";
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Checked = true;
            this.radioButton4.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.radioButton4.ForeColor = System.Drawing.Color.White;
            this.radioButton4.Location = new System.Drawing.Point(11, 21);
            this.radioButton4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(83, 27);
            this.radioButton4.TabIndex = 44;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "Ember";
            this.radioButton4.UseVisualStyleBackColor = true;
            this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioButton2);
            this.groupBox1.Controls.Add(this.radioButton1);
            this.groupBox1.Location = new System.Drawing.Point(657, 255);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Size = new System.Drawing.Size(100, 126);
            this.groupBox1.TabIndex = 48;
            this.groupBox1.TabStop = false;
            // 
            // kezolap
            // 
            this.kezolap.Controls.Add(this.groupBox2);
            this.kezolap.Controls.Add(this.groupBox1);
            this.kezolap.Controls.Add(this.Cim);
            this.kezolap.Controls.Add(this.button2);
            this.kezolap.Controls.Add(this.button1);
            this.kezolap.Controls.Add(this.textBox2);
            this.kezolap.Controls.Add(this.textBox1);
            this.kezolap.Controls.Add(this.O);
            this.kezolap.Controls.Add(this.X);
            this.kezolap.Location = new System.Drawing.Point(297, 35);
            this.kezolap.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.kezolap.Name = "kezolap";
            this.kezolap.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.kezolap.Size = new System.Drawing.Size(1100, 900);
            this.kezolap.TabIndex = 51;
            this.kezolap.TabStop = false;
            // 
            // EmbxEmb_3x3
            // 
            this.EmbxEmb_3x3.Controls.Add(this.gyozteslab1);
            this.EmbxEmb_3x3.Controls.Add(this.menub1);
            this.EmbxEmb_3x3.Controls.Add(this.restartb1);
            this.EmbxEmb_3x3.Controls.Add(this.Player1_3x3_E);
            this.EmbxEmb_3x3.Controls.Add(this.Player2_3x3_E);
            this.EmbxEmb_3x3.Controls.Add(this.O_p1);
            this.EmbxEmb_3x3.Controls.Add(this.X_P1);
            this.EmbxEmb_3x3.Controls.Add(this.progressBar4);
            this.EmbxEmb_3x3.Controls.Add(this.progressBar1);
            this.EmbxEmb_3x3.Controls.Add(this.progressBar3);
            this.EmbxEmb_3x3.Controls.Add(this.label1);
            this.EmbxEmb_3x3.Controls.Add(this.label4);
            this.EmbxEmb_3x3.Controls.Add(this.label9);
            this.EmbxEmb_3x3.Controls.Add(this.label8);
            this.EmbxEmb_3x3.Controls.Add(this.label7);
            this.EmbxEmb_3x3.Controls.Add(this.label6);
            this.EmbxEmb_3x3.Controls.Add(this.label5);
            this.EmbxEmb_3x3.Controls.Add(this.label3);
            this.EmbxEmb_3x3.Controls.Add(this.label2);
            this.EmbxEmb_3x3.Controls.Add(this.progressBar2);
            this.EmbxEmb_3x3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.EmbxEmb_3x3.Location = new System.Drawing.Point(297, 35);
            this.EmbxEmb_3x3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.EmbxEmb_3x3.Name = "EmbxEmb_3x3";
            this.EmbxEmb_3x3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.EmbxEmb_3x3.Size = new System.Drawing.Size(1100, 900);
            this.EmbxEmb_3x3.TabIndex = 52;
            this.EmbxEmb_3x3.TabStop = false;
            // 
            // gyozteslab1
            // 
            this.gyozteslab1.AutoSize = true;
            this.gyozteslab1.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.gyozteslab1.ForeColor = System.Drawing.Color.White;
            this.gyozteslab1.Location = new System.Drawing.Point(68, 208);
            this.gyozteslab1.Name = "gyozteslab1";
            this.gyozteslab1.Size = new System.Drawing.Size(23, 23);
            this.gyozteslab1.TabIndex = 39;
            this.gyozteslab1.Text = "w";
            this.gyozteslab1.Visible = false;
            // 
            // menub1
            // 
            this.menub1.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.menub1.ForeColor = System.Drawing.Color.Black;
            this.menub1.Location = new System.Drawing.Point(27, 326);
            this.menub1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.menub1.Name = "menub1";
            this.menub1.Size = new System.Drawing.Size(125, 62);
            this.menub1.TabIndex = 38;
            this.menub1.Text = "Menu";
            this.menub1.UseVisualStyleBackColor = true;
            this.menub1.Visible = false;
            this.menub1.Click += new System.EventHandler(this.menub1_Click);
            // 
            // restartb1
            // 
            this.restartb1.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.restartb1.ForeColor = System.Drawing.Color.Black;
            this.restartb1.Location = new System.Drawing.Point(27, 258);
            this.restartb1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.restartb1.Name = "restartb1";
            this.restartb1.Size = new System.Drawing.Size(125, 62);
            this.restartb1.TabIndex = 37;
            this.restartb1.Text = "Restart";
            this.restartb1.UseVisualStyleBackColor = true;
            this.restartb1.Visible = false;
            this.restartb1.Click += new System.EventHandler(this.restartb_Click);
            // 
            // Player1_3x3_E
            // 
            this.Player1_3x3_E.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.Player1_3x3_E.Font = new System.Drawing.Font("Microsoft YaHei", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Player1_3x3_E.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Player1_3x3_E.Location = new System.Drawing.Point(95, 36);
            this.Player1_3x3_E.Name = "Player1_3x3_E";
            this.Player1_3x3_E.Size = new System.Drawing.Size(110, 30);
            this.Player1_3x3_E.TabIndex = 36;
            // 
            // Player2_3x3_E
            // 
            this.Player2_3x3_E.Font = new System.Drawing.Font("Microsoft YaHei", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Player2_3x3_E.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Player2_3x3_E.Location = new System.Drawing.Point(95, 82);
            this.Player2_3x3_E.Name = "Player2_3x3_E";
            this.Player2_3x3_E.Size = new System.Drawing.Size(110, 30);
            this.Player2_3x3_E.TabIndex = 35;
            // 
            // O_p1
            // 
            this.O_p1.AutoSize = true;
            this.O_p1.Font = new System.Drawing.Font("Microsoft YaHei", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.O_p1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.O_p1.Location = new System.Drawing.Point(27, 75);
            this.O_p1.Name = "O_p1";
            this.O_p1.Size = new System.Drawing.Size(54, 43);
            this.O_p1.TabIndex = 34;
            this.O_p1.Text = "O:";
            // 
            // X_P1
            // 
            this.X_P1.AutoSize = true;
            this.X_P1.Font = new System.Drawing.Font("Microsoft YaHei", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.X_P1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.X_P1.Location = new System.Drawing.Point(33, 30);
            this.X_P1.Name = "X_P1";
            this.X_P1.Size = new System.Drawing.Size(48, 43);
            this.X_P1.TabIndex = 33;
            this.X_P1.Text = "X:";
            // 
            // progressBar4
            // 
            this.progressBar4.BackColor = System.Drawing.Color.Red;
            this.progressBar4.Location = new System.Drawing.Point(225, 549);
            this.progressBar4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar4.Name = "progressBar4";
            this.progressBar4.Size = new System.Drawing.Size(700, 25);
            this.progressBar4.TabIndex = 32;
            // 
            // progressBar1
            // 
            this.progressBar1.BackColor = System.Drawing.Color.Red;
            this.progressBar1.Location = new System.Drawing.Point(436, 73);
            this.progressBar1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(25, 700);
            this.progressBar1.TabIndex = 31;
            // 
            // progressBar3
            // 
            this.progressBar3.BackColor = System.Drawing.Color.Red;
            this.progressBar3.Location = new System.Drawing.Point(711, 73);
            this.progressBar3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar3.Name = "progressBar3";
            this.progressBar3.Size = new System.Drawing.Size(25, 700);
            this.progressBar3.TabIndex = 30;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 64.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(232, 91);
            this.label1.Margin = new System.Windows.Forms.Padding(0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(168, 158);
            this.label1.TabIndex = 28;
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei UI", 64.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.Control;
            this.label4.Location = new System.Drawing.Point(232, 342);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(168, 158);
            this.label4.TabIndex = 27;
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label9
            // 
            this.label9.AccessibleRole = System.Windows.Forms.AccessibleRole.Link;
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label9.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label9.Font = new System.Drawing.Font("Microsoft YaHei UI", 64.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.Control;
            this.label9.Location = new System.Drawing.Point(767, 599);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(168, 158);
            this.label9.TabIndex = 26;
            this.label9.Tag = "";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label8.Font = new System.Drawing.Font("Microsoft YaHei UI", 64.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.Control;
            this.label8.Location = new System.Drawing.Point(508, 599);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(168, 158);
            this.label8.TabIndex = 25;
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label7.Font = new System.Drawing.Font("Microsoft YaHei UI", 64.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.Control;
            this.label7.Location = new System.Drawing.Point(232, 599);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(168, 158);
            this.label7.TabIndex = 24;
            this.label7.Tag = "";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label6.Font = new System.Drawing.Font("Microsoft YaHei UI", 64.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.Control;
            this.label6.Location = new System.Drawing.Point(767, 342);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(168, 158);
            this.label6.TabIndex = 23;
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label5.Font = new System.Drawing.Font("Microsoft YaHei UI", 64.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.Control;
            this.label5.Location = new System.Drawing.Point(508, 342);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(168, 158);
            this.label5.TabIndex = 22;
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei UI", 64.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.Control;
            this.label3.Location = new System.Drawing.Point(767, 91);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(168, 158);
            this.label3.TabIndex = 21;
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei UI", 64.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.Control;
            this.label2.Location = new System.Drawing.Point(508, 91);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(168, 158);
            this.label2.TabIndex = 20;
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // progressBar2
            // 
            this.progressBar2.BackColor = System.Drawing.Color.Red;
            this.progressBar2.Location = new System.Drawing.Point(235, 295);
            this.progressBar2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar2.Name = "progressBar2";
            this.progressBar2.Size = new System.Drawing.Size(700, 25);
            this.progressBar2.TabIndex = 17;
            // 
            // EmbxEmb_5x5
            // 
            this.EmbxEmb_5x5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.EmbxEmb_5x5.Controls.Add(this.gyozteslab2);
            this.EmbxEmb_5x5.Controls.Add(this.menub2);
            this.EmbxEmb_5x5.Controls.Add(this.restartb2);
            this.EmbxEmb_5x5.Controls.Add(this.progressBar9);
            this.EmbxEmb_5x5.Controls.Add(this.progressBar8);
            this.EmbxEmb_5x5.Controls.Add(this.progressBar7);
            this.EmbxEmb_5x5.Controls.Add(this.progressBar6);
            this.EmbxEmb_5x5.Controls.Add(this.progressBar5);
            this.EmbxEmb_5x5.Controls.Add(this.progressBar10);
            this.EmbxEmb_5x5.Controls.Add(this.label34);
            this.EmbxEmb_5x5.Controls.Add(this.label33);
            this.EmbxEmb_5x5.Controls.Add(this.label32);
            this.EmbxEmb_5x5.Controls.Add(this.label31);
            this.EmbxEmb_5x5.Controls.Add(this.label30);
            this.EmbxEmb_5x5.Controls.Add(this.label29);
            this.EmbxEmb_5x5.Controls.Add(this.label28);
            this.EmbxEmb_5x5.Controls.Add(this.label27);
            this.EmbxEmb_5x5.Controls.Add(this.label26);
            this.EmbxEmb_5x5.Controls.Add(this.label25);
            this.EmbxEmb_5x5.Controls.Add(this.label24);
            this.EmbxEmb_5x5.Controls.Add(this.label23);
            this.EmbxEmb_5x5.Controls.Add(this.label22);
            this.EmbxEmb_5x5.Controls.Add(this.label21);
            this.EmbxEmb_5x5.Controls.Add(this.label20);
            this.EmbxEmb_5x5.Controls.Add(this.label19);
            this.EmbxEmb_5x5.Controls.Add(this.label18);
            this.EmbxEmb_5x5.Controls.Add(this.label17);
            this.EmbxEmb_5x5.Controls.Add(this.label16);
            this.EmbxEmb_5x5.Controls.Add(this.label15);
            this.EmbxEmb_5x5.Controls.Add(this.label13);
            this.EmbxEmb_5x5.Controls.Add(this.label12);
            this.EmbxEmb_5x5.Controls.Add(this.label14);
            this.EmbxEmb_5x5.Controls.Add(this.label11);
            this.EmbxEmb_5x5.Controls.Add(this.label10);
            this.EmbxEmb_5x5.Controls.Add(this.progressBar11);
            this.EmbxEmb_5x5.Controls.Add(this.progressBar12);
            this.EmbxEmb_5x5.Controls.Add(this.Player1_5x5_E);
            this.EmbxEmb_5x5.Controls.Add(this.Player2_5x5_E);
            this.EmbxEmb_5x5.Controls.Add(this.O_P2);
            this.EmbxEmb_5x5.Controls.Add(this.X_P2);
            this.EmbxEmb_5x5.Location = new System.Drawing.Point(297, 35);
            this.EmbxEmb_5x5.Name = "EmbxEmb_5x5";
            this.EmbxEmb_5x5.Size = new System.Drawing.Size(1100, 900);
            this.EmbxEmb_5x5.TabIndex = 53;
            this.EmbxEmb_5x5.TabStop = false;
            // 
            // gyozteslab2
            // 
            this.gyozteslab2.AutoSize = true;
            this.gyozteslab2.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.gyozteslab2.ForeColor = System.Drawing.Color.White;
            this.gyozteslab2.Location = new System.Drawing.Point(74, 203);
            this.gyozteslab2.Name = "gyozteslab2";
            this.gyozteslab2.Size = new System.Drawing.Size(23, 23);
            this.gyozteslab2.TabIndex = 122;
            this.gyozteslab2.Text = "w";
            this.gyozteslab2.Visible = false;
            // 
            // menub2
            // 
            this.menub2.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.menub2.ForeColor = System.Drawing.Color.Black;
            this.menub2.Location = new System.Drawing.Point(48, 311);
            this.menub2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.menub2.Name = "menub2";
            this.menub2.Size = new System.Drawing.Size(125, 62);
            this.menub2.TabIndex = 121;
            this.menub2.Text = "Menu";
            this.menub2.UseVisualStyleBackColor = true;
            this.menub2.Visible = false;
            this.menub2.Click += new System.EventHandler(this.menub2_Click);
            // 
            // restartb2
            // 
            this.restartb2.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.restartb2.ForeColor = System.Drawing.Color.Black;
            this.restartb2.Location = new System.Drawing.Point(48, 244);
            this.restartb2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.restartb2.Name = "restartb2";
            this.restartb2.Size = new System.Drawing.Size(125, 62);
            this.restartb2.TabIndex = 120;
            this.restartb2.Text = "Restart";
            this.restartb2.UseVisualStyleBackColor = true;
            this.restartb2.Visible = false;
            this.restartb2.Click += new System.EventHandler(this.restartb2_Click);
            // 
            // progressBar9
            // 
            this.progressBar9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.progressBar9.Location = new System.Drawing.Point(228, 655);
            this.progressBar9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar9.Name = "progressBar9";
            this.progressBar9.Size = new System.Drawing.Size(775, 25);
            this.progressBar9.TabIndex = 119;
            // 
            // progressBar8
            // 
            this.progressBar8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.progressBar8.Location = new System.Drawing.Point(228, 489);
            this.progressBar8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar8.Name = "progressBar8";
            this.progressBar8.Size = new System.Drawing.Size(775, 25);
            this.progressBar8.TabIndex = 118;
            // 
            // progressBar7
            // 
            this.progressBar7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.progressBar7.Location = new System.Drawing.Point(228, 322);
            this.progressBar7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar7.Name = "progressBar7";
            this.progressBar7.Size = new System.Drawing.Size(775, 25);
            this.progressBar7.TabIndex = 117;
            // 
            // progressBar6
            // 
            this.progressBar6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.progressBar6.Location = new System.Drawing.Point(362, 25);
            this.progressBar6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar6.Name = "progressBar6";
            this.progressBar6.Size = new System.Drawing.Size(25, 789);
            this.progressBar6.TabIndex = 116;
            // 
            // progressBar5
            // 
            this.progressBar5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.progressBar5.Location = new System.Drawing.Point(524, 26);
            this.progressBar5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar5.Name = "progressBar5";
            this.progressBar5.Size = new System.Drawing.Size(25, 789);
            this.progressBar5.TabIndex = 115;
            // 
            // progressBar10
            // 
            this.progressBar10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.progressBar10.Location = new System.Drawing.Point(686, 26);
            this.progressBar10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar10.Name = "progressBar10";
            this.progressBar10.Size = new System.Drawing.Size(25, 789);
            this.progressBar10.TabIndex = 114;
            // 
            // label34
            // 
            this.label34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label34.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label34.ForeColor = System.Drawing.SystemColors.Control;
            this.label34.Location = new System.Drawing.Point(878, 689);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(125, 126);
            this.label34.TabIndex = 113;
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label34.Click += new System.EventHandler(this.label34_Click);
            // 
            // label33
            // 
            this.label33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label33.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label33.ForeColor = System.Drawing.SystemColors.Control;
            this.label33.Location = new System.Drawing.Point(715, 689);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(125, 126);
            this.label33.TabIndex = 112;
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label33.Click += new System.EventHandler(this.label33_Click);
            // 
            // label32
            // 
            this.label32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label32.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label32.ForeColor = System.Drawing.SystemColors.Control;
            this.label32.Location = new System.Drawing.Point(554, 689);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(125, 126);
            this.label32.TabIndex = 111;
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label32.Click += new System.EventHandler(this.label32_Click);
            // 
            // label31
            // 
            this.label31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label31.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label31.ForeColor = System.Drawing.SystemColors.Control;
            this.label31.Location = new System.Drawing.Point(393, 689);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(125, 126);
            this.label31.TabIndex = 110;
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label31.Click += new System.EventHandler(this.label31_Click);
            // 
            // label30
            // 
            this.label30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label30.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label30.ForeColor = System.Drawing.SystemColors.Control;
            this.label30.Location = new System.Drawing.Point(230, 689);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(125, 126);
            this.label30.TabIndex = 109;
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label30.Click += new System.EventHandler(this.label30_Click);
            // 
            // label29
            // 
            this.label29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label29.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label29.ForeColor = System.Drawing.SystemColors.Control;
            this.label29.Location = new System.Drawing.Point(878, 522);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(125, 126);
            this.label29.TabIndex = 108;
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label29.Click += new System.EventHandler(this.label29_Click);
            // 
            // label28
            // 
            this.label28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label28.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label28.ForeColor = System.Drawing.SystemColors.Control;
            this.label28.Location = new System.Drawing.Point(716, 522);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(125, 126);
            this.label28.TabIndex = 107;
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label28.Click += new System.EventHandler(this.label28_Click);
            // 
            // label27
            // 
            this.label27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label27.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label27.ForeColor = System.Drawing.SystemColors.Control;
            this.label27.Location = new System.Drawing.Point(554, 522);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(125, 126);
            this.label27.TabIndex = 106;
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label27.Click += new System.EventHandler(this.label27_Click);
            // 
            // label26
            // 
            this.label26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label26.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label26.ForeColor = System.Drawing.SystemColors.Control;
            this.label26.Location = new System.Drawing.Point(393, 522);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(125, 126);
            this.label26.TabIndex = 105;
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label26.Click += new System.EventHandler(this.label26_Click);
            // 
            // label25
            // 
            this.label25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label25.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label25.ForeColor = System.Drawing.SystemColors.Control;
            this.label25.Location = new System.Drawing.Point(231, 522);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(125, 126);
            this.label25.TabIndex = 104;
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label25.Click += new System.EventHandler(this.label25_Click);
            // 
            // label24
            // 
            this.label24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label24.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label24.ForeColor = System.Drawing.SystemColors.Control;
            this.label24.Location = new System.Drawing.Point(878, 354);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(125, 126);
            this.label24.TabIndex = 103;
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label24.Click += new System.EventHandler(this.label24_Click);
            // 
            // label23
            // 
            this.label23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label23.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label23.ForeColor = System.Drawing.SystemColors.Control;
            this.label23.Location = new System.Drawing.Point(716, 354);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(125, 126);
            this.label23.TabIndex = 102;
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label23.Click += new System.EventHandler(this.label23_Click);
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label22.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label22.ForeColor = System.Drawing.SystemColors.Control;
            this.label22.Location = new System.Drawing.Point(554, 354);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(125, 126);
            this.label22.TabIndex = 101;
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label22.Click += new System.EventHandler(this.label22_Click);
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label21.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label21.ForeColor = System.Drawing.SystemColors.Control;
            this.label21.Location = new System.Drawing.Point(393, 354);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(125, 126);
            this.label21.TabIndex = 100;
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label21.Click += new System.EventHandler(this.label21_Click);
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label20.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label20.ForeColor = System.Drawing.SystemColors.Control;
            this.label20.Location = new System.Drawing.Point(230, 353);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(125, 126);
            this.label20.TabIndex = 99;
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label20.Click += new System.EventHandler(this.label20_Click);
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label19.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label19.ForeColor = System.Drawing.SystemColors.Control;
            this.label19.Location = new System.Drawing.Point(878, 189);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(125, 126);
            this.label19.TabIndex = 98;
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label19.Click += new System.EventHandler(this.label19_Click);
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label18.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label18.ForeColor = System.Drawing.SystemColors.Control;
            this.label18.Location = new System.Drawing.Point(716, 189);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(125, 126);
            this.label18.TabIndex = 97;
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label18.Click += new System.EventHandler(this.label18_Click);
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label17.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label17.ForeColor = System.Drawing.SystemColors.Control;
            this.label17.Location = new System.Drawing.Point(554, 189);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(125, 126);
            this.label17.TabIndex = 96;
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label16.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label16.ForeColor = System.Drawing.SystemColors.Control;
            this.label16.Location = new System.Drawing.Point(393, 189);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(125, 126);
            this.label16.TabIndex = 95;
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label16.Click += new System.EventHandler(this.label16_Click);
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label15.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label15.ForeColor = System.Drawing.SystemColors.Control;
            this.label15.Location = new System.Drawing.Point(230, 189);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(125, 126);
            this.label15.TabIndex = 94;
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label13.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label13.ForeColor = System.Drawing.SystemColors.Control;
            this.label13.Location = new System.Drawing.Point(717, 26);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(125, 126);
            this.label13.TabIndex = 93;
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label12.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label12.ForeColor = System.Drawing.SystemColors.Control;
            this.label12.Location = new System.Drawing.Point(554, 26);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(125, 126);
            this.label12.TabIndex = 92;
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label14.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label14.ForeColor = System.Drawing.SystemColors.Control;
            this.label14.Location = new System.Drawing.Point(878, 26);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(125, 126);
            this.label14.TabIndex = 91;
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label11.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label11.ForeColor = System.Drawing.SystemColors.Control;
            this.label11.Location = new System.Drawing.Point(393, 25);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(125, 126);
            this.label11.TabIndex = 90;
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label10.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label10.ForeColor = System.Drawing.SystemColors.Control;
            this.label10.Location = new System.Drawing.Point(230, 25);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(125, 126);
            this.label10.TabIndex = 89;
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // progressBar11
            // 
            this.progressBar11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.progressBar11.Location = new System.Drawing.Point(228, 153);
            this.progressBar11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar11.Name = "progressBar11";
            this.progressBar11.Size = new System.Drawing.Size(775, 25);
            this.progressBar11.TabIndex = 88;
            // 
            // progressBar12
            // 
            this.progressBar12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.progressBar12.Location = new System.Drawing.Point(848, 25);
            this.progressBar12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar12.Name = "progressBar12";
            this.progressBar12.Size = new System.Drawing.Size(25, 789);
            this.progressBar12.TabIndex = 87;
            // 
            // Player1_5x5_E
            // 
            this.Player1_5x5_E.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.Player1_5x5_E.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Player1_5x5_E.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Player1_5x5_E.Location = new System.Drawing.Point(91, 20);
            this.Player1_5x5_E.Name = "Player1_5x5_E";
            this.Player1_5x5_E.Size = new System.Drawing.Size(83, 30);
            this.Player1_5x5_E.TabIndex = 86;
            // 
            // Player2_5x5_E
            // 
            this.Player2_5x5_E.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.Player2_5x5_E.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Player2_5x5_E.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Player2_5x5_E.Location = new System.Drawing.Point(91, 71);
            this.Player2_5x5_E.Name = "Player2_5x5_E";
            this.Player2_5x5_E.Size = new System.Drawing.Size(83, 30);
            this.Player2_5x5_E.TabIndex = 85;
            // 
            // O_P2
            // 
            this.O_P2.AutoSize = true;
            this.O_P2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.O_P2.Font = new System.Drawing.Font("Microsoft YaHei", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.O_P2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.O_P2.Location = new System.Drawing.Point(28, 61);
            this.O_P2.Name = "O_P2";
            this.O_P2.Size = new System.Drawing.Size(54, 43);
            this.O_P2.TabIndex = 84;
            this.O_P2.Text = "O:";
            // 
            // X_P2
            // 
            this.X_P2.AutoSize = true;
            this.X_P2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.X_P2.Font = new System.Drawing.Font("Microsoft YaHei", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.X_P2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.X_P2.Location = new System.Drawing.Point(35, 9);
            this.X_P2.Name = "X_P2";
            this.X_P2.Size = new System.Drawing.Size(48, 43);
            this.X_P2.TabIndex = 83;
            this.X_P2.Text = "X:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.ClientSize = new System.Drawing.Size(1924, 1055);
            this.Controls.Add(this.kezolap);
            this.Controls.Add(this.EmbxEmb_3x3);
            this.Controls.Add(this.EmbxEmb_5x5);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.kezolap.ResumeLayout(false);
            this.kezolap.PerformLayout();
            this.EmbxEmb_3x3.ResumeLayout(false);
            this.EmbxEmb_3x3.PerformLayout();
            this.EmbxEmb_5x5.ResumeLayout(false);
            this.EmbxEmb_5x5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label Cim;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label O;
        private System.Windows.Forms.Label X;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox kezolap;
        private System.Windows.Forms.GroupBox EmbxEmb_3x3;
        private System.Windows.Forms.Label gyozteslab1;
        private System.Windows.Forms.Button menub1;
        private System.Windows.Forms.Button restartb1;
        private System.Windows.Forms.Label Player1_3x3_E;
        private System.Windows.Forms.Label Player2_3x3_E;
        private System.Windows.Forms.Label O_p1;
        private System.Windows.Forms.Label X_P1;
        private System.Windows.Forms.ProgressBar progressBar4;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.ProgressBar progressBar3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ProgressBar progressBar2;
        private System.Windows.Forms.GroupBox EmbxEmb_5x5;
        private System.Windows.Forms.Label gyozteslab2;
        private System.Windows.Forms.Button menub2;
        private System.Windows.Forms.Button restartb2;
        private System.Windows.Forms.ProgressBar progressBar9;
        private System.Windows.Forms.ProgressBar progressBar8;
        private System.Windows.Forms.ProgressBar progressBar7;
        private System.Windows.Forms.ProgressBar progressBar6;
        private System.Windows.Forms.ProgressBar progressBar5;
        private System.Windows.Forms.ProgressBar progressBar10;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ProgressBar progressBar11;
        private System.Windows.Forms.ProgressBar progressBar12;
        private System.Windows.Forms.Label Player1_5x5_E;
        private System.Windows.Forms.Label Player2_5x5_E;
        private System.Windows.Forms.Label O_P2;
        private System.Windows.Forms.Label X_P2;
    }
}

