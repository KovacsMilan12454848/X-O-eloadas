﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace GRobbox
{
    public partial class Form1 : Form
    {
        public System.Windows.Forms.Label[,] labels_3x3;
        public System.Windows.Forms.Label[,] labels_5x5;
        public Form1()
        {
            InitializeComponent();
            
            labels_3x3 = new System.Windows.Forms.Label[,]
            {
                { label1, label2, label3 },
                { label4, label5, label6 },
                { label7, label8, label9 }
            };
            
            
            labels_5x5 = new System.Windows.Forms.Label[,]
            {
                    { label10, label11, label12, label13, label14 },
                    { label15, label16, label17, label18, label19 },
                    { label20, label21, label22, label23, label24 },
                    { label25, label26, label27, label28, label29 },
                    { label30, label31, label32, label33, label34 }
                };
            
            
        }

        Random rnd = new Random();
        string[,] board_3x3 = { { "1", "2", "3" }, { "4", "5", "6" }, { "7", "8", "9" } };
        string[,] board_5x5 = { { "1", "2", "3","4", "5" },{ "6", "7", "8","9", "10" },{ "11", "12", "13","14", "15" },{ "16", "17", "18","19", "20" },{ "21", "22", "23","24", "25" }};

        int num = 0;
        bool vanNyertes = false;

        public void visible()
        {
            kezolap.Visible = true;
            EmbxEmb_3x3.Visible = false;
            EmbxEmb_5x5.Visible = false;
        }

        //          CHECK
        //---------------------------------------------------------------------------------------------------------------------------------------

        // Ember x Ember 
        public string Check()
        {


            if (num % 2 == 0)
            {
                num++;

                return "X";
            }
            else
            {
                num++;

                return "O";
            }
            // megnez van e nyertes     
        }


        public void Check_Gep_3()
        {

            int retries = 0;

            while (retries < 10)
            {
                int ind = rnd.Next(3);
                int ind2 = rnd.Next(3);

                if (board_3x3[ind, ind2] != "X" && board_3x3[ind, ind2] != "O")
                {
                    board_3x3[ind, ind2] = "X";
                    labels_3x3[ind, ind2].Text = "X";

                    num++;
                    break;
                }
                retries++;
            }
        }
        /*
        public void Check_Gep5()
        {

            int retries = 0;

            while (retries < 25)
            {

                int tomb1 = rnd.Next(5);
                int tomb2 = rnd.Next(5);
                if (board_5x5[tomb1, tomb2] != "X" && board_5x5[tomb1, tomb2] != "O")
                {
                    board_5x5[tomb1, tomb2] = "X";
                    labels_5x5[tomb1, tomb2].Text = "X";

                    num++;
                    break;
                }
                retries++;
            }
        }
        */

        //          RESTART
        //---------------------------------------------------------------------------------------------------------------------------------------
        public void resetgame()
        {

            foreach (System.Windows.Forms.Label i in labels_3x3)
            {
                i.Text = "";
            }
            num = 0;
            vanNyertes = false;

            board_3x3 = new string[,]
            {
                { "1", "2", "3" },
                { "4", "5", "6" },
                { "7", "8", "9" }
            };
            restartb1.Visible = false;
            menub1.Visible = false;
            gyozteslab1.Visible = false;
        }
        public void menu()
        {
            gyozteslab1.Visible = true;
            restartb1.Visible = true;
            menub1.Visible = true;

        }

        //===============================================================

        public void resetgame2()
        {

            foreach (System.Windows.Forms.Label i in labels_5x5)
            {
                i.Text = "";
            }
            num = 0;
            vanNyertes = false;



            board_5x5 = new string[,]{
                            { "1", "2", "3","4", "5" },
                            { "6", "7", "8","9", "10" },
                            { "11", "12", "13","14", "15" },
                            { "16", "17", "18","19", "20" },
                            { "21", "22", "23","24", "25" }
            };
            restartb2.Visible = false;
            menub2.Visible = false;
            gyozteslab2.Visible = false;
        }




        public void menu2()
        {
            gyozteslab2.Visible = true;
            restartb2.Visible = true;
            menub2.Visible = true;

        }


        //                     NYERÉSSI LEHETŐSÉGEK
        //---------------------------------------------------------------------------------------------------------------------------------------



        // EMBER x EMBER 3x3
        public void VanNyertes_3x3()
        {
            if (num > 3)
            {


                // ---
                for (int i = 0; i <= 2; i++)
                {
                    if (board_3x3[i, 0] == board_3x3[i, 1] && board_3x3[i, 1] == board_3x3[i, 2])
                    {
                        gyozteslab1.Text = $"A Győztes: {board_3x3[i, 0]}";
                        menu();
                        vanNyertes = true;

                    }

                }
                // |
                for (int i = 0; i <= 2; i++)
                {
                    if (board_3x3[0, i] == board_3x3[1, i] && board_3x3[2, i] == board_3x3[1, i])
                    {
                        gyozteslab1.Text = $"A Győztes: {board_3x3[0, i]}";
                        menu();
                        vanNyertes = true;

                    }

                }
                // \, /
                if (board_3x3[0, 0] == board_3x3[1, 1] && board_3x3[2, 2] == board_3x3[1, 1])
                {

                    gyozteslab1.Text = $"A Győztes: {board_3x3[0, 0]}";
                    menu();
                    vanNyertes = true;
                }

                if (board_3x3[0, 2] == board_3x3[1, 1] && board_3x3[2, 0] == board_3x3[1, 1])
                {
                    gyozteslab1.Text = $"A Győztes: {board_3x3[0, 2]}";
                    menu();
                    vanNyertes = true;

                }
                if (num == 9 && !vanNyertes)
                {
                    gyozteslab1.Text = $"Döntetlen";  // Display "Döntetlen" for a tie
                    menu();
                }

            }

        }


        public void VanNyertes_5x5()
        {


            if (num > 5)
            {


                // ---
                for (int i = 0; i < 5; i++)
                {
                    if (board_5x5[i, 0] == board_5x5[i, 1] && board_5x5[i, 1] == board_5x5[i, 2] && board_5x5[i, 2] == board_5x5[i, 3] && board_5x5[i, 3] == board_5x5[i, 4])
                    {
                        gyozteslab2.Text = $"A Győztes: {board_5x5[i, 0]}";
                        menu2();
                        vanNyertes = true;

                    }

                }
                // |
                for (int i = 0; i < 5; i++)
                {
                    if (board_5x5[0, i] == board_5x5[1, i] && board_5x5[1, i] == board_5x5[2, i] && board_5x5[2, i] == board_5x5[3, i] && board_5x5[3, i] == board_5x5[4, i])
                    {
                        gyozteslab2.Text = $"A Győztes: {board_5x5[0, i]}";
                        menu2();
                        vanNyertes = true;

                    }

                }
                // \, /
                if (board_5x5[0, 0] == board_5x5[1, 1] && board_5x5[1, 1] == board_5x5[2, 2] && board_5x5[2, 2] == board_5x5[3, 3] && board_5x5[3, 3] == board_5x5[4, 4])
                {
                    gyozteslab2.Text = $"A Győztes: {board_5x5[0, 0]}";
                    menu2();
                    vanNyertes = true;
                }

                if (board_5x5[0, 4] == board_5x5[1, 3] && board_5x5[1, 3] == board_5x5[2, 2] && board_5x5[2, 2] == board_5x5[3, 1] && board_5x5[3, 1] == board_5x5[4, 0])
                {
                    gyozteslab2.Text = $"A Győztes: {board_5x5[0, 4]}";
                    menu2();
                    vanNyertes = true;
                }


                if (num == 25 && vanNyertes == false)
                {
                    label1.Text = $"Döntetlen";
                    menu2(); 

                }

            }

        }




        //                     GUI-s  FELÜLET
        //---------------------------------------------------------------------------------------------------------------------------------------



        //                     KEZELŐ RÉSZ
        //---------------------------------------------------------------------------------------------------------------------------------------

        private void Form1_Load(object sender, EventArgs e)
        {
            visible();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            //SQL szerver
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //STEAR GOMB
            if (textBox1.Text != "" && textBox2.Text != "" && radioButton1.Checked == true && radioButton4.Checked == true)
            {
                //  EMBER x EMBER /3x3
                kezolap.Visible = false;
                EmbxEmb_3x3.Visible = true;
                Player1_3x3_E.Text= textBox1.Text;
                Player2_3x3_E.Text = textBox2.Text;
                
            }
            if (textBox1.Text != "" && textBox2.Text != "" && radioButton2.Checked == true && radioButton4.Checked == true)
            {
                //  EMBER x EMBER /3x3
                kezolap.Visible = false;
                EmbxEmb_5x5.Visible = true;
                Player1_5x5_E.Text = textBox1.Text;
                Player2_5x5_E.Text = textBox2.Text;
                
            }

        }



        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            //  EMBER
            textBox2.Visible = true;
            O.Visible = true;

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            // GÉP
            textBox2.Visible = false;
            O.Visible = false;


        }




        //                     LABEL KEZELŐ RÉSZ
        //---------------------------------------------------------------------------------------------------------------------------------------


        //                  EMB_x_EMB 3x3
        //-------------------------------------------------------------------------------------------------------------------------------------------
        private void label1_Click(object sender, EventArgs e)
        {
            if (label1.Text == "" && vanNyertes != true)
            {

                label1.Text = Check();
                board_3x3[0, 0] = label1.Text;
                VanNyertes_3x3();


            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

            if (label2.Text == "" && vanNyertes != true)
            {

                label2.Text = Check();
                board_3x3[0, 1] = label2.Text;
                VanNyertes_3x3();


            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

            if (label3.Text == "" && vanNyertes != true)
            {

                label3.Text = Check();
                board_3x3[0, 2] = label3.Text;
                VanNyertes_3x3();


            }
        }

        private void label4_Click(object sender, EventArgs e)
        {
            if (label4.Text == "" && vanNyertes != true)
            {

                label4.Text = Check();
                board_3x3[1, 0] = label4.Text;
                VanNyertes_3x3();


            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

            if (label5.Text == "" && vanNyertes != true)
            {

                label5.Text = Check();
                board_3x3[1, 1] = label5.Text;
                VanNyertes_3x3();


            }
        }

        private void label6_Click(object sender, EventArgs e)
        {
            if (label6.Text == "" && vanNyertes != true)
            {

                label6.Text = Check();
                board_3x3[1, 2] = label6.Text;
                VanNyertes_3x3();


            }
        }

        private void label7_Click(object sender, EventArgs e)
        {

            if (label7.Text == "" && vanNyertes != true)
            {

                label7.Text = Check();
                board_3x3[2, 0] = label7.Text;
                VanNyertes_3x3();


            }
        }

        private void label8_Click(object sender, EventArgs e)
        {

            if (label8.Text == "" && vanNyertes != true)
            {

                label8.Text = Check();
                board_3x3[2, 1] = label8.Text;
                VanNyertes_3x3();


            }
        }

        private void label9_Click(object sender, EventArgs e)
        {
            if (label9.Text == "" && vanNyertes != true)
            {

                label9.Text = Check();
                board_3x3[2, 2] = label9.Text;
                VanNyertes_3x3();


            }
        }

        private void restartb_Click(object sender, EventArgs e)
        {
            resetgame();


        }

        private void menub1_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            kezolap.Visible = true;
            EmbxEmb_3x3.Visible = false;
            resetgame();

        }


        //                          EMB_x_EMB 5x5
        //-------------------------------------------------------------------------------------------------------------------------------------------


        //                               gyozteslab2
        private void label10_Click(object sender, EventArgs e)
        {
            if (label10.Text == "" && vanNyertes != true)
            {

                label10.Text = Check();
                board_5x5[0, 0] = label10.Text;
                VanNyertes_5x5();

            }
        }

        private void label11_Click(object sender, EventArgs e)
        {
            if (label11.Text == "" && vanNyertes != true)
            {

                label11.Text = Check();
                board_5x5[0, 1] = label11.Text;
                VanNyertes_5x5();

            }
        }

        private void label12_Click(object sender, EventArgs e)
        {
            if (label12.Text == "" && vanNyertes != true)
            {

                label12.Text = Check();
                board_5x5[0, 2] = label12.Text;
                VanNyertes_5x5();

            }
        }

        private void label13_Click(object sender, EventArgs e)
        {
            if (label13.Text == "" && vanNyertes != true)
            {

                label13.Text = Check();
                board_5x5[0, 3] = label13.Text;
                VanNyertes_5x5();

            }
        }

        private void label14_Click(object sender, EventArgs e)
        {
            if (label14.Text == "" && vanNyertes != true)
            {

                label14.Text = Check();
                board_5x5[0, 4] = label14.Text;
                VanNyertes_5x5();

            }
        }

        private void label15_Click(object sender, EventArgs e)
        {
            if (label15.Text == "" && vanNyertes != true)
            {

                label15.Text = Check();
                board_5x5[1, 0] = label15.Text;
                VanNyertes_5x5();

            }
        }

        private void label16_Click(object sender, EventArgs e)
        {
            if (label16.Text == "" && vanNyertes != true)
            {

                label16.Text = Check();
                board_5x5[1, 1] = label16.Text;
                VanNyertes_5x5();

            }
        }

        private void label17_Click(object sender, EventArgs e)
        {
            if (label17.Text == "" && vanNyertes != true)
            {

                label17.Text = Check();
                board_5x5[1, 2] = label17.Text;
                VanNyertes_5x5();

            }
        }

        private void label18_Click(object sender, EventArgs e)
        {
            if (label18.Text == "" && vanNyertes != true)
            {

                label18.Text = Check();
                board_5x5[1, 3] = label18.Text;
                VanNyertes_5x5();

            }
        }

        private void label19_Click(object sender, EventArgs e)
        {
            if (label19.Text == "" && vanNyertes != true)
            {

                label19.Text = Check();
                board_5x5[1, 4] = label19.Text;
                VanNyertes_5x5();

            }
        }

        private void label20_Click(object sender, EventArgs e)
        {
            if (label20.Text == "" && vanNyertes != true)
            {

                label20.Text = Check();
                board_5x5[2, 0] = label20.Text;
                VanNyertes_5x5();

            }
        }

        private void label21_Click(object sender, EventArgs e)
        {
            if (label21.Text == "" && vanNyertes != true)
            {

                label21.Text = Check();
                board_5x5[2, 1] = label21.Text;
                VanNyertes_5x5();

            }
        }

        private void label22_Click(object sender, EventArgs e)
        {
            if (label22.Text == "" && vanNyertes != true)
            {

                label22.Text = Check();
                board_5x5[2, 2] = label22.Text;
                VanNyertes_5x5();

            }
        }

        private void label23_Click(object sender, EventArgs e)
        {
            if (label23.Text == "" && vanNyertes != true)
            {

                label23.Text = Check();
                board_5x5[2, 3] = label23.Text;
                VanNyertes_5x5();

            }
        }

        private void label24_Click(object sender, EventArgs e)
        {
            if (label24.Text == "" && vanNyertes != true)
            {

                label24.Text = Check();
                board_5x5[2, 4] = label24.Text;
                VanNyertes_5x5();

            }
        }

        private void label25_Click(object sender, EventArgs e)
        {
            if (label25.Text == "" && vanNyertes != true)
            {

                label25.Text = Check();
                board_5x5[3, 0] = label25.Text;
                VanNyertes_5x5();

            }
        }

        private void label26_Click(object sender, EventArgs e)
        {
            if (label26.Text == "" && vanNyertes != true)
            {

                label26.Text = Check();
                board_5x5[3, 1] = label26.Text;
                VanNyertes_5x5();

            }
        }

        private void label27_Click(object sender, EventArgs e)
        {
            if (label27.Text == "" && vanNyertes != true)
            {

                label27.Text = Check();
                board_5x5[3, 2] = label27.Text;
                VanNyertes_5x5();

            }
        }

        private void label28_Click(object sender, EventArgs e)
        {
            if (label28.Text == "" && vanNyertes != true)
            {

                label28.Text = Check();
                board_5x5[3, 3] = label28.Text;
                VanNyertes_5x5();

            }
        }

        private void label29_Click(object sender, EventArgs e)
        {
            if (label29.Text == "" && vanNyertes != true)
            {

                label29.Text = Check();
                board_5x5[3,4] = label29.Text;
                VanNyertes_5x5();

            }
        }

        private void label30_Click(object sender, EventArgs e)
        {
            if (label30.Text == "" && vanNyertes != true)
            {

                label30.Text = Check();
                board_5x5[4, 0] = label30.Text;
                VanNyertes_5x5();

            }
        }

        private void label31_Click(object sender, EventArgs e)
        {
            if (label31.Text == "" && vanNyertes != true)
            {

                label31.Text = Check();
                board_5x5[4, 1] = label31.Text;
                VanNyertes_5x5();

            }
        }

        private void label32_Click(object sender, EventArgs e)
        {
            if (label32.Text == "" && vanNyertes != true)
            {

                label32.Text = Check();
                board_5x5[4,2] = label32.Text;
                VanNyertes_5x5();

            }
        }

        private void label33_Click(object sender, EventArgs e)
        {
            if (label33.Text == "" && vanNyertes != true)
            {

                label33.Text = Check();
                board_5x5[4, 3] = label33.Text;
                VanNyertes_5x5();

            }
        }

        private void label34_Click(object sender, EventArgs e)
        {
            if (label34.Text == "" && vanNyertes != true)
            {

                label34.Text = Check();
                board_5x5[4, 4] = label34.Text;
                VanNyertes_5x5();

            }
        }

        private void restartb2_Click(object sender, EventArgs e)
        {
            resetgame2();
        }

        private void menub2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            kezolap.Visible = true;
            EmbxEmb_5x5.Visible = false;
            resetgame2();
        }
    }
}
