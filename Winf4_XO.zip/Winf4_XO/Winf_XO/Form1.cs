﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Winf_XO
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
           if  (textBox1.Text != "" && textBox2.Text != "")
           {
                if (radioButton1.Checked == true)
                {
                    Form2 form = new Form2();
                    form.P1 = textBox1.Text;
                    form.P2 = textBox2.Text;
                    form.ShowDialog();
                }
                if (radioButton2.Checked == true)
                {
                    Form3 form = new Form3();
                    form.P1 = textBox1.Text;
                    form.P2 = textBox2.Text;
                    form.ShowDialog();
                }
           }
            
            
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            textBox2.Visible = false;
            label2.Visible = false;
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            textBox2.Visible = true;
            label2.Visible = true;
        }
    }
}
