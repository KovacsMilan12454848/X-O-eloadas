﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Winf_XO
{
    public partial class Form1 : Form
    {

        string[,] board = { {"1", "2","3"}, { "4", "5", "6" }, { "7", "8", "9" }};

        public Form1()
        {
            InitializeComponent();
           


        }

        public void Form1_Load(object sender, EventArgs e)
        {



        }

        int num = 0;
        bool vanNyertes = false;
        public string Check()
        {
           

            if (num % 2 == 0)
            {
                num++;
                
                return "X";
            }
            else
            {
                num++;
                
                return "O";
            }
            // megnez van e nyertes

           
{

                   
            } 

            
        }

        public void VanNyertes() {
           
            
            if (num > 3)
            {
                

                // ---
                for (int i = 0; i <= 2; i++)
                {
                    if (board[i, 0] == board[i, 1] && board[i, 1] == board[i, 2])
                    {
                        MessageBox.Show(board[i, 0]);
                        vanNyertes = true;
                      
                    }

                }
                // |
                for (int i = 0; i <= 2; i++)
                {
                    if (board[0, i] == board[1, i] && board[2, i] == board[1, i])
                    {
                        MessageBox.Show(board[0, i]);
                        vanNyertes = true;
                        
                    }

                }
                // \, /
                if (board[0,0] == board[1,1] && board[2, 2] == board[1,1]){
                    MessageBox.Show(board[0, 0]);
                    vanNyertes = true;
                    
                }

                if (board[0, 2] == board[1, 1] && board[2, 0] == board[1, 1])
                {
                    MessageBox.Show(board[0, 2]);
                    vanNyertes = true;
              
                }

                if (num == 9 && vanNyertes == false)
                {
                    MessageBox.Show("Dontetlen");
                }

            }

        }



        public void label1_Click_1(object sender, EventArgs e)
        {
            
            if (label1.Text != "X" && label1.Text != "O")
            {
                label1.Text = Check();

                board[0, 0] = label1.Text;
                VanNyertes();

            }


           
        }


        private void label2_Click(object sender, EventArgs e)
        {

            if (label2.Text != "X" && label2.Text != "O")
            {
                label2.Text = Check();
                board[0, 1] = label2.Text;
                VanNyertes();
            }


        }

        private void label3_Click_1(object sender, EventArgs e)
        {

            if (label3.Text != "X" && label3.Text != "O")
            {
                label3.Text = Check();
                board[0, 2] = label3.Text;
                VanNyertes();
            }

        }

        private void label4_Click(object sender, EventArgs e)
        {
            if (label4.Text != "X" && label4.Text != "O")
            {
                label4.Text = Check();
                board[1, 0] = label4.Text;
                VanNyertes();
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

            if (label5.Text != "X" && label5.Text != "O")
            {
                label5.Text = Check();
                board[1, 1] = label5.Text;
                VanNyertes();
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {
            if (label6.Text != "X" && label6.Text != "O")
            {
                label6.Text = Check();
                board[1, 2] = label6.Text;
                VanNyertes();
            }
        }

        private void label7_Click(object sender, EventArgs e)
        {
            if (label7.Text != "X" && label7.Text != "O")
            {
                label7.Text = Check();
                board[2, 0] = label7.Text;
                VanNyertes();
            }

        }

        private void label8_Click(object sender, EventArgs e)
        {
            if (label8.Text != "X" && label8.Text != "O")
            {
                label8.Text = Check();
                board[2, 1] = label8.Text;
                    VanNyertes();
            }


        }

        private void label9_Click(object sender, EventArgs e)
        {
            if (label9.Text != "X" && label9.Text != "O")
            {
                label9.Text = Check();
                board[2, 2] = label9.Text;
                    VanNyertes();
                
            }
        }






        










        private void Form1_Load_1(object sender, EventArgs e)
        {

        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void progressBar3_Click(object sender, EventArgs e)
        {

        }
    }
}
