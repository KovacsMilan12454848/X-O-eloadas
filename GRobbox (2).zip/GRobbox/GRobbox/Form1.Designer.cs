﻿namespace GRobbox
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Cim = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.O = new System.Windows.Forms.Label();
            this.X = new System.Windows.Forms.Label();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.kezolap = new System.Windows.Forms.GroupBox();
            this.EmbxEmb_3x3 = new System.Windows.Forms.GroupBox();
            this.gyozteslab1 = new System.Windows.Forms.Label();
            this.menub1 = new System.Windows.Forms.Button();
            this.restartb1 = new System.Windows.Forms.Button();
            this.Player1_3x3_E = new System.Windows.Forms.Label();
            this.Player2_3x3_E = new System.Windows.Forms.Label();
            this.O_p1 = new System.Windows.Forms.Label();
            this.X_P1 = new System.Windows.Forms.Label();
            this.progressBar4 = new System.Windows.Forms.ProgressBar();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.progressBar3 = new System.Windows.Forms.ProgressBar();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.progressBar2 = new System.Windows.Forms.ProgressBar();
            this.EmbxEmb_5x5 = new System.Windows.Forms.GroupBox();
            this.gyozteslab2 = new System.Windows.Forms.Label();
            this.menub2 = new System.Windows.Forms.Button();
            this.restartb2 = new System.Windows.Forms.Button();
            this.progressBar9 = new System.Windows.Forms.ProgressBar();
            this.progressBar8 = new System.Windows.Forms.ProgressBar();
            this.progressBar7 = new System.Windows.Forms.ProgressBar();
            this.progressBar6 = new System.Windows.Forms.ProgressBar();
            this.progressBar5 = new System.Windows.Forms.ProgressBar();
            this.progressBar10 = new System.Windows.Forms.ProgressBar();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.progressBar11 = new System.Windows.Forms.ProgressBar();
            this.progressBar12 = new System.Windows.Forms.ProgressBar();
            this.Player1_5x5_E = new System.Windows.Forms.Label();
            this.Player2_5x5_E = new System.Windows.Forms.Label();
            this.O_P2 = new System.Windows.Forms.Label();
            this.X_P2 = new System.Windows.Forms.Label();
            this.EMbxGEP_3x3 = new System.Windows.Forms.GroupBox();
            this.gyozteslab3 = new System.Windows.Forms.Label();
            this.menub3 = new System.Windows.Forms.Button();
            this.restartb3 = new System.Windows.Forms.Button();
            this.Player1_3x3_G = new System.Windows.Forms.Label();
            this.X_P3 = new System.Windows.Forms.Label();
            this.progressBar13 = new System.Windows.Forms.ProgressBar();
            this.progressBar14 = new System.Windows.Forms.ProgressBar();
            this.progressBar15 = new System.Windows.Forms.ProgressBar();
            this.label35 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.progressBar16 = new System.Windows.Forms.ProgressBar();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.gyozteslab4 = new System.Windows.Forms.Label();
            this.menub4 = new System.Windows.Forms.Button();
            this.restartb4 = new System.Windows.Forms.Button();
            this.progressBar17 = new System.Windows.Forms.ProgressBar();
            this.progressBar18 = new System.Windows.Forms.ProgressBar();
            this.progressBar19 = new System.Windows.Forms.ProgressBar();
            this.progressBar20 = new System.Windows.Forms.ProgressBar();
            this.progressBar21 = new System.Windows.Forms.ProgressBar();
            this.progressBar22 = new System.Windows.Forms.ProgressBar();
            this.label68 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.progressBar23 = new System.Windows.Forms.ProgressBar();
            this.progressBar24 = new System.Windows.Forms.ProgressBar();
            this.Player1_5x5_G = new System.Windows.Forms.Label();
            this.X_P4 = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.kezolap.SuspendLayout();
            this.EmbxEmb_3x3.SuspendLayout();
            this.EmbxEmb_5x5.SuspendLayout();
            this.EMbxGEP_3x3.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // Cim
            // 
            this.Cim.AutoSize = true;
            this.Cim.Font = new System.Drawing.Font("Microsoft YaHei", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Cim.ForeColor = System.Drawing.Color.White;
            this.Cim.Location = new System.Drawing.Point(435, 147);
            this.Cim.Name = "Cim";
            this.Cim.Size = new System.Drawing.Size(323, 66);
            this.Cim.TabIndex = 46;
            this.Cim.Text = "Tic-Tac-Toe";
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button2.Location = new System.Drawing.Point(259, 515);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(669, 71);
            this.button2.TabIndex = 41;
            this.button2.Text = "Start";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button1.Location = new System.Drawing.Point(259, 420);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(669, 52);
            this.button1.TabIndex = 40;
            this.button1.Text = "History";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft YaHei", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox2.Location = new System.Drawing.Point(312, 342);
            this.textBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(249, 38);
            this.textBox2.TabIndex = 39;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft YaHei", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox1.Location = new System.Drawing.Point(312, 270);
            this.textBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(249, 38);
            this.textBox1.TabIndex = 38;
            // 
            // O
            // 
            this.O.AutoSize = true;
            this.O.Font = new System.Drawing.Font("Microsoft YaHei", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.O.ForeColor = System.Drawing.Color.White;
            this.O.Location = new System.Drawing.Point(251, 335);
            this.O.Name = "O";
            this.O.Size = new System.Drawing.Size(46, 44);
            this.O.TabIndex = 37;
            this.O.Text = "O";
            // 
            // X
            // 
            this.X.AutoSize = true;
            this.X.Font = new System.Drawing.Font("Microsoft YaHei", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.X.ForeColor = System.Drawing.Color.White;
            this.X.Location = new System.Drawing.Point(251, 263);
            this.X.Name = "X";
            this.X.Size = new System.Drawing.Size(42, 44);
            this.X.TabIndex = 36;
            this.X.Text = "X";
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.radioButton2.ForeColor = System.Drawing.Color.White;
            this.radioButton2.Location = new System.Drawing.Point(20, 69);
            this.radioButton2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(60, 27);
            this.radioButton2.TabIndex = 45;
            this.radioButton2.Text = "5x5";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.radioButton1.ForeColor = System.Drawing.Color.White;
            this.radioButton1.Location = new System.Drawing.Point(20, 21);
            this.radioButton1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(60, 27);
            this.radioButton1.TabIndex = 44;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "3x3";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioButton3);
            this.groupBox2.Controls.Add(this.radioButton4);
            this.groupBox2.Location = new System.Drawing.Point(821, 255);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Size = new System.Drawing.Size(108, 126);
            this.groupBox2.TabIndex = 49;
            this.groupBox2.TabStop = false;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.radioButton3.ForeColor = System.Drawing.Color.White;
            this.radioButton3.Location = new System.Drawing.Point(11, 70);
            this.radioButton3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(65, 27);
            this.radioButton3.TabIndex = 45;
            this.radioButton3.Text = "Gép";
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Checked = true;
            this.radioButton4.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.radioButton4.ForeColor = System.Drawing.Color.White;
            this.radioButton4.Location = new System.Drawing.Point(11, 21);
            this.radioButton4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(83, 27);
            this.radioButton4.TabIndex = 44;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "Ember";
            this.radioButton4.UseVisualStyleBackColor = true;
            this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioButton2);
            this.groupBox1.Controls.Add(this.radioButton1);
            this.groupBox1.Location = new System.Drawing.Point(657, 255);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Size = new System.Drawing.Size(100, 126);
            this.groupBox1.TabIndex = 48;
            this.groupBox1.TabStop = false;
            // 
            // kezolap
            // 
            this.kezolap.Controls.Add(this.groupBox2);
            this.kezolap.Controls.Add(this.groupBox1);
            this.kezolap.Controls.Add(this.Cim);
            this.kezolap.Controls.Add(this.button2);
            this.kezolap.Controls.Add(this.button1);
            this.kezolap.Controls.Add(this.textBox2);
            this.kezolap.Controls.Add(this.textBox1);
            this.kezolap.Controls.Add(this.O);
            this.kezolap.Controls.Add(this.X);
            this.kezolap.Location = new System.Drawing.Point(26, 41);
            this.kezolap.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.kezolap.Name = "kezolap";
            this.kezolap.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.kezolap.Size = new System.Drawing.Size(1100, 916);
            this.kezolap.TabIndex = 51;
            this.kezolap.TabStop = false;
            // 
            // EmbxEmb_3x3
            // 
            this.EmbxEmb_3x3.Controls.Add(this.gyozteslab1);
            this.EmbxEmb_3x3.Controls.Add(this.menub1);
            this.EmbxEmb_3x3.Controls.Add(this.restartb1);
            this.EmbxEmb_3x3.Controls.Add(this.Player1_3x3_E);
            this.EmbxEmb_3x3.Controls.Add(this.Player2_3x3_E);
            this.EmbxEmb_3x3.Controls.Add(this.O_p1);
            this.EmbxEmb_3x3.Controls.Add(this.X_P1);
            this.EmbxEmb_3x3.Controls.Add(this.progressBar4);
            this.EmbxEmb_3x3.Controls.Add(this.progressBar1);
            this.EmbxEmb_3x3.Controls.Add(this.progressBar3);
            this.EmbxEmb_3x3.Controls.Add(this.label1);
            this.EmbxEmb_3x3.Controls.Add(this.label4);
            this.EmbxEmb_3x3.Controls.Add(this.label9);
            this.EmbxEmb_3x3.Controls.Add(this.label8);
            this.EmbxEmb_3x3.Controls.Add(this.label7);
            this.EmbxEmb_3x3.Controls.Add(this.label6);
            this.EmbxEmb_3x3.Controls.Add(this.label5);
            this.EmbxEmb_3x3.Controls.Add(this.label3);
            this.EmbxEmb_3x3.Controls.Add(this.label2);
            this.EmbxEmb_3x3.Controls.Add(this.progressBar2);
            this.EmbxEmb_3x3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.EmbxEmb_3x3.Location = new System.Drawing.Point(26, 49);
            this.EmbxEmb_3x3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.EmbxEmb_3x3.Name = "EmbxEmb_3x3";
            this.EmbxEmb_3x3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.EmbxEmb_3x3.Size = new System.Drawing.Size(1100, 900);
            this.EmbxEmb_3x3.TabIndex = 52;
            this.EmbxEmb_3x3.TabStop = false;
            // 
            // gyozteslab1
            // 
            this.gyozteslab1.AutoSize = true;
            this.gyozteslab1.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.gyozteslab1.ForeColor = System.Drawing.Color.White;
            this.gyozteslab1.Location = new System.Drawing.Point(68, 208);
            this.gyozteslab1.Name = "gyozteslab1";
            this.gyozteslab1.Size = new System.Drawing.Size(23, 23);
            this.gyozteslab1.TabIndex = 39;
            this.gyozteslab1.Text = "w";
            this.gyozteslab1.Visible = false;
            // 
            // menub1
            // 
            this.menub1.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.menub1.ForeColor = System.Drawing.Color.Black;
            this.menub1.Location = new System.Drawing.Point(27, 326);
            this.menub1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.menub1.Name = "menub1";
            this.menub1.Size = new System.Drawing.Size(125, 62);
            this.menub1.TabIndex = 38;
            this.menub1.Text = "Menu";
            this.menub1.UseVisualStyleBackColor = true;
            this.menub1.Visible = false;
            this.menub1.Click += new System.EventHandler(this.menub1_Click);
            // 
            // restartb1
            // 
            this.restartb1.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.restartb1.ForeColor = System.Drawing.Color.Black;
            this.restartb1.Location = new System.Drawing.Point(27, 258);
            this.restartb1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.restartb1.Name = "restartb1";
            this.restartb1.Size = new System.Drawing.Size(125, 62);
            this.restartb1.TabIndex = 37;
            this.restartb1.Text = "Restart";
            this.restartb1.UseVisualStyleBackColor = true;
            this.restartb1.Visible = false;
            this.restartb1.Click += new System.EventHandler(this.restartb_Click);
            // 
            // Player1_3x3_E
            // 
            this.Player1_3x3_E.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.Player1_3x3_E.Font = new System.Drawing.Font("Microsoft YaHei", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Player1_3x3_E.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Player1_3x3_E.Location = new System.Drawing.Point(95, 36);
            this.Player1_3x3_E.Name = "Player1_3x3_E";
            this.Player1_3x3_E.Size = new System.Drawing.Size(110, 30);
            this.Player1_3x3_E.TabIndex = 36;
            // 
            // Player2_3x3_E
            // 
            this.Player2_3x3_E.Font = new System.Drawing.Font("Microsoft YaHei", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Player2_3x3_E.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Player2_3x3_E.Location = new System.Drawing.Point(95, 82);
            this.Player2_3x3_E.Name = "Player2_3x3_E";
            this.Player2_3x3_E.Size = new System.Drawing.Size(110, 30);
            this.Player2_3x3_E.TabIndex = 35;
            // 
            // O_p1
            // 
            this.O_p1.AutoSize = true;
            this.O_p1.Font = new System.Drawing.Font("Microsoft YaHei", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.O_p1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.O_p1.Location = new System.Drawing.Point(27, 75);
            this.O_p1.Name = "O_p1";
            this.O_p1.Size = new System.Drawing.Size(54, 43);
            this.O_p1.TabIndex = 34;
            this.O_p1.Text = "O:";
            // 
            // X_P1
            // 
            this.X_P1.AutoSize = true;
            this.X_P1.Font = new System.Drawing.Font("Microsoft YaHei", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.X_P1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.X_P1.Location = new System.Drawing.Point(33, 30);
            this.X_P1.Name = "X_P1";
            this.X_P1.Size = new System.Drawing.Size(48, 43);
            this.X_P1.TabIndex = 33;
            this.X_P1.Text = "X:";
            // 
            // progressBar4
            // 
            this.progressBar4.BackColor = System.Drawing.Color.Red;
            this.progressBar4.Location = new System.Drawing.Point(225, 549);
            this.progressBar4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar4.Name = "progressBar4";
            this.progressBar4.Size = new System.Drawing.Size(700, 25);
            this.progressBar4.TabIndex = 32;
            // 
            // progressBar1
            // 
            this.progressBar1.BackColor = System.Drawing.Color.Red;
            this.progressBar1.Location = new System.Drawing.Point(436, 73);
            this.progressBar1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(25, 700);
            this.progressBar1.TabIndex = 31;
            // 
            // progressBar3
            // 
            this.progressBar3.BackColor = System.Drawing.Color.Red;
            this.progressBar3.Location = new System.Drawing.Point(711, 73);
            this.progressBar3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar3.Name = "progressBar3";
            this.progressBar3.Size = new System.Drawing.Size(25, 700);
            this.progressBar3.TabIndex = 30;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 64.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(232, 91);
            this.label1.Margin = new System.Windows.Forms.Padding(0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(168, 158);
            this.label1.TabIndex = 28;
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei UI", 64.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.Control;
            this.label4.Location = new System.Drawing.Point(232, 342);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(168, 158);
            this.label4.TabIndex = 27;
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label9
            // 
            this.label9.AccessibleRole = System.Windows.Forms.AccessibleRole.Link;
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label9.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label9.Font = new System.Drawing.Font("Microsoft YaHei UI", 64.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.Control;
            this.label9.Location = new System.Drawing.Point(767, 599);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(168, 158);
            this.label9.TabIndex = 26;
            this.label9.Tag = "";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label8.Font = new System.Drawing.Font("Microsoft YaHei UI", 64.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.Control;
            this.label8.Location = new System.Drawing.Point(508, 599);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(168, 158);
            this.label8.TabIndex = 25;
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label7.Font = new System.Drawing.Font("Microsoft YaHei UI", 64.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.Control;
            this.label7.Location = new System.Drawing.Point(232, 599);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(168, 158);
            this.label7.TabIndex = 24;
            this.label7.Tag = "";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label6.Font = new System.Drawing.Font("Microsoft YaHei UI", 64.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.Control;
            this.label6.Location = new System.Drawing.Point(767, 342);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(168, 158);
            this.label6.TabIndex = 23;
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label5.Font = new System.Drawing.Font("Microsoft YaHei UI", 64.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.Control;
            this.label5.Location = new System.Drawing.Point(508, 342);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(168, 158);
            this.label5.TabIndex = 22;
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei UI", 64.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.Control;
            this.label3.Location = new System.Drawing.Point(767, 91);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(168, 158);
            this.label3.TabIndex = 21;
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei UI", 64.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.Control;
            this.label2.Location = new System.Drawing.Point(508, 91);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(168, 158);
            this.label2.TabIndex = 20;
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // progressBar2
            // 
            this.progressBar2.BackColor = System.Drawing.Color.Red;
            this.progressBar2.Location = new System.Drawing.Point(235, 295);
            this.progressBar2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar2.Name = "progressBar2";
            this.progressBar2.Size = new System.Drawing.Size(700, 25);
            this.progressBar2.TabIndex = 17;
            // 
            // EmbxEmb_5x5
            // 
            this.EmbxEmb_5x5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.EmbxEmb_5x5.Controls.Add(this.gyozteslab2);
            this.EmbxEmb_5x5.Controls.Add(this.menub2);
            this.EmbxEmb_5x5.Controls.Add(this.restartb2);
            this.EmbxEmb_5x5.Controls.Add(this.progressBar9);
            this.EmbxEmb_5x5.Controls.Add(this.progressBar8);
            this.EmbxEmb_5x5.Controls.Add(this.progressBar7);
            this.EmbxEmb_5x5.Controls.Add(this.progressBar6);
            this.EmbxEmb_5x5.Controls.Add(this.progressBar5);
            this.EmbxEmb_5x5.Controls.Add(this.progressBar10);
            this.EmbxEmb_5x5.Controls.Add(this.label34);
            this.EmbxEmb_5x5.Controls.Add(this.label33);
            this.EmbxEmb_5x5.Controls.Add(this.label32);
            this.EmbxEmb_5x5.Controls.Add(this.label31);
            this.EmbxEmb_5x5.Controls.Add(this.label30);
            this.EmbxEmb_5x5.Controls.Add(this.label29);
            this.EmbxEmb_5x5.Controls.Add(this.label28);
            this.EmbxEmb_5x5.Controls.Add(this.label27);
            this.EmbxEmb_5x5.Controls.Add(this.label26);
            this.EmbxEmb_5x5.Controls.Add(this.label25);
            this.EmbxEmb_5x5.Controls.Add(this.label24);
            this.EmbxEmb_5x5.Controls.Add(this.label23);
            this.EmbxEmb_5x5.Controls.Add(this.label22);
            this.EmbxEmb_5x5.Controls.Add(this.label21);
            this.EmbxEmb_5x5.Controls.Add(this.label20);
            this.EmbxEmb_5x5.Controls.Add(this.label19);
            this.EmbxEmb_5x5.Controls.Add(this.label18);
            this.EmbxEmb_5x5.Controls.Add(this.label17);
            this.EmbxEmb_5x5.Controls.Add(this.label16);
            this.EmbxEmb_5x5.Controls.Add(this.label15);
            this.EmbxEmb_5x5.Controls.Add(this.label13);
            this.EmbxEmb_5x5.Controls.Add(this.label12);
            this.EmbxEmb_5x5.Controls.Add(this.label14);
            this.EmbxEmb_5x5.Controls.Add(this.label11);
            this.EmbxEmb_5x5.Controls.Add(this.label10);
            this.EmbxEmb_5x5.Controls.Add(this.progressBar11);
            this.EmbxEmb_5x5.Controls.Add(this.progressBar12);
            this.EmbxEmb_5x5.Controls.Add(this.Player1_5x5_E);
            this.EmbxEmb_5x5.Controls.Add(this.Player2_5x5_E);
            this.EmbxEmb_5x5.Controls.Add(this.O_P2);
            this.EmbxEmb_5x5.Controls.Add(this.X_P2);
            this.EmbxEmb_5x5.Location = new System.Drawing.Point(26, 49);
            this.EmbxEmb_5x5.Name = "EmbxEmb_5x5";
            this.EmbxEmb_5x5.Size = new System.Drawing.Size(1100, 900);
            this.EmbxEmb_5x5.TabIndex = 53;
            this.EmbxEmb_5x5.TabStop = false;
            // 
            // gyozteslab2
            // 
            this.gyozteslab2.AutoSize = true;
            this.gyozteslab2.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.gyozteslab2.ForeColor = System.Drawing.Color.White;
            this.gyozteslab2.Location = new System.Drawing.Point(74, 203);
            this.gyozteslab2.Name = "gyozteslab2";
            this.gyozteslab2.Size = new System.Drawing.Size(23, 23);
            this.gyozteslab2.TabIndex = 122;
            this.gyozteslab2.Text = "w";
            this.gyozteslab2.Visible = false;
            // 
            // menub2
            // 
            this.menub2.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.menub2.ForeColor = System.Drawing.Color.Black;
            this.menub2.Location = new System.Drawing.Point(48, 311);
            this.menub2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.menub2.Name = "menub2";
            this.menub2.Size = new System.Drawing.Size(125, 62);
            this.menub2.TabIndex = 121;
            this.menub2.Text = "Menu";
            this.menub2.UseVisualStyleBackColor = true;
            this.menub2.Visible = false;
            this.menub2.Click += new System.EventHandler(this.menub2_Click);
            // 
            // restartb2
            // 
            this.restartb2.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.restartb2.ForeColor = System.Drawing.Color.Black;
            this.restartb2.Location = new System.Drawing.Point(48, 244);
            this.restartb2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.restartb2.Name = "restartb2";
            this.restartb2.Size = new System.Drawing.Size(125, 62);
            this.restartb2.TabIndex = 120;
            this.restartb2.Text = "Restart";
            this.restartb2.UseVisualStyleBackColor = true;
            this.restartb2.Visible = false;
            this.restartb2.Click += new System.EventHandler(this.restartb2_Click);
            // 
            // progressBar9
            // 
            this.progressBar9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.progressBar9.Location = new System.Drawing.Point(228, 655);
            this.progressBar9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar9.Name = "progressBar9";
            this.progressBar9.Size = new System.Drawing.Size(775, 25);
            this.progressBar9.TabIndex = 119;
            // 
            // progressBar8
            // 
            this.progressBar8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.progressBar8.Location = new System.Drawing.Point(228, 489);
            this.progressBar8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar8.Name = "progressBar8";
            this.progressBar8.Size = new System.Drawing.Size(775, 25);
            this.progressBar8.TabIndex = 118;
            // 
            // progressBar7
            // 
            this.progressBar7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.progressBar7.Location = new System.Drawing.Point(228, 322);
            this.progressBar7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar7.Name = "progressBar7";
            this.progressBar7.Size = new System.Drawing.Size(775, 25);
            this.progressBar7.TabIndex = 117;
            // 
            // progressBar6
            // 
            this.progressBar6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.progressBar6.Location = new System.Drawing.Point(362, 25);
            this.progressBar6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar6.Name = "progressBar6";
            this.progressBar6.Size = new System.Drawing.Size(25, 789);
            this.progressBar6.TabIndex = 116;
            // 
            // progressBar5
            // 
            this.progressBar5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.progressBar5.Location = new System.Drawing.Point(524, 26);
            this.progressBar5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar5.Name = "progressBar5";
            this.progressBar5.Size = new System.Drawing.Size(25, 789);
            this.progressBar5.TabIndex = 115;
            // 
            // progressBar10
            // 
            this.progressBar10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.progressBar10.Location = new System.Drawing.Point(686, 26);
            this.progressBar10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar10.Name = "progressBar10";
            this.progressBar10.Size = new System.Drawing.Size(25, 789);
            this.progressBar10.TabIndex = 114;
            // 
            // label34
            // 
            this.label34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label34.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label34.ForeColor = System.Drawing.SystemColors.Control;
            this.label34.Location = new System.Drawing.Point(878, 689);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(125, 126);
            this.label34.TabIndex = 113;
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label34.Click += new System.EventHandler(this.label34_Click);
            // 
            // label33
            // 
            this.label33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label33.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label33.ForeColor = System.Drawing.SystemColors.Control;
            this.label33.Location = new System.Drawing.Point(715, 689);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(125, 126);
            this.label33.TabIndex = 112;
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label33.Click += new System.EventHandler(this.label33_Click);
            // 
            // label32
            // 
            this.label32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label32.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label32.ForeColor = System.Drawing.SystemColors.Control;
            this.label32.Location = new System.Drawing.Point(554, 689);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(125, 126);
            this.label32.TabIndex = 111;
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label32.Click += new System.EventHandler(this.label32_Click);
            // 
            // label31
            // 
            this.label31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label31.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label31.ForeColor = System.Drawing.SystemColors.Control;
            this.label31.Location = new System.Drawing.Point(393, 689);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(125, 126);
            this.label31.TabIndex = 110;
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label31.Click += new System.EventHandler(this.label31_Click);
            // 
            // label30
            // 
            this.label30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label30.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label30.ForeColor = System.Drawing.SystemColors.Control;
            this.label30.Location = new System.Drawing.Point(230, 689);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(125, 126);
            this.label30.TabIndex = 109;
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label30.Click += new System.EventHandler(this.label30_Click);
            // 
            // label29
            // 
            this.label29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label29.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label29.ForeColor = System.Drawing.SystemColors.Control;
            this.label29.Location = new System.Drawing.Point(878, 522);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(125, 126);
            this.label29.TabIndex = 108;
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label29.Click += new System.EventHandler(this.label29_Click);
            // 
            // label28
            // 
            this.label28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label28.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label28.ForeColor = System.Drawing.SystemColors.Control;
            this.label28.Location = new System.Drawing.Point(716, 522);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(125, 126);
            this.label28.TabIndex = 107;
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label28.Click += new System.EventHandler(this.label28_Click);
            // 
            // label27
            // 
            this.label27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label27.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label27.ForeColor = System.Drawing.SystemColors.Control;
            this.label27.Location = new System.Drawing.Point(554, 522);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(125, 126);
            this.label27.TabIndex = 106;
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label27.Click += new System.EventHandler(this.label27_Click);
            // 
            // label26
            // 
            this.label26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label26.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label26.ForeColor = System.Drawing.SystemColors.Control;
            this.label26.Location = new System.Drawing.Point(393, 522);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(125, 126);
            this.label26.TabIndex = 105;
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label26.Click += new System.EventHandler(this.label26_Click);
            // 
            // label25
            // 
            this.label25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label25.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label25.ForeColor = System.Drawing.SystemColors.Control;
            this.label25.Location = new System.Drawing.Point(231, 522);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(125, 126);
            this.label25.TabIndex = 104;
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label25.Click += new System.EventHandler(this.label25_Click);
            // 
            // label24
            // 
            this.label24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label24.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label24.ForeColor = System.Drawing.SystemColors.Control;
            this.label24.Location = new System.Drawing.Point(878, 354);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(125, 126);
            this.label24.TabIndex = 103;
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label24.Click += new System.EventHandler(this.label24_Click);
            // 
            // label23
            // 
            this.label23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label23.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label23.ForeColor = System.Drawing.SystemColors.Control;
            this.label23.Location = new System.Drawing.Point(716, 354);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(125, 126);
            this.label23.TabIndex = 102;
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label23.Click += new System.EventHandler(this.label23_Click);
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label22.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label22.ForeColor = System.Drawing.SystemColors.Control;
            this.label22.Location = new System.Drawing.Point(554, 354);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(125, 126);
            this.label22.TabIndex = 101;
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label22.Click += new System.EventHandler(this.label22_Click);
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label21.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label21.ForeColor = System.Drawing.SystemColors.Control;
            this.label21.Location = new System.Drawing.Point(393, 354);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(125, 126);
            this.label21.TabIndex = 100;
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label21.Click += new System.EventHandler(this.label21_Click);
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label20.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label20.ForeColor = System.Drawing.SystemColors.Control;
            this.label20.Location = new System.Drawing.Point(230, 353);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(125, 126);
            this.label20.TabIndex = 99;
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label20.Click += new System.EventHandler(this.label20_Click);
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label19.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label19.ForeColor = System.Drawing.SystemColors.Control;
            this.label19.Location = new System.Drawing.Point(878, 189);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(125, 126);
            this.label19.TabIndex = 98;
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label19.Click += new System.EventHandler(this.label19_Click);
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label18.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label18.ForeColor = System.Drawing.SystemColors.Control;
            this.label18.Location = new System.Drawing.Point(716, 189);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(125, 126);
            this.label18.TabIndex = 97;
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label18.Click += new System.EventHandler(this.label18_Click);
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label17.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label17.ForeColor = System.Drawing.SystemColors.Control;
            this.label17.Location = new System.Drawing.Point(554, 189);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(125, 126);
            this.label17.TabIndex = 96;
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label16.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label16.ForeColor = System.Drawing.SystemColors.Control;
            this.label16.Location = new System.Drawing.Point(393, 189);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(125, 126);
            this.label16.TabIndex = 95;
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label16.Click += new System.EventHandler(this.label16_Click);
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label15.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label15.ForeColor = System.Drawing.SystemColors.Control;
            this.label15.Location = new System.Drawing.Point(230, 189);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(125, 126);
            this.label15.TabIndex = 94;
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label13.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label13.ForeColor = System.Drawing.SystemColors.Control;
            this.label13.Location = new System.Drawing.Point(717, 26);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(125, 126);
            this.label13.TabIndex = 93;
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label12.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label12.ForeColor = System.Drawing.SystemColors.Control;
            this.label12.Location = new System.Drawing.Point(554, 26);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(125, 126);
            this.label12.TabIndex = 92;
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label14.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label14.ForeColor = System.Drawing.SystemColors.Control;
            this.label14.Location = new System.Drawing.Point(878, 26);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(125, 126);
            this.label14.TabIndex = 91;
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label11.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label11.ForeColor = System.Drawing.SystemColors.Control;
            this.label11.Location = new System.Drawing.Point(393, 25);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(125, 126);
            this.label11.TabIndex = 90;
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label10.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label10.ForeColor = System.Drawing.SystemColors.Control;
            this.label10.Location = new System.Drawing.Point(230, 25);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(125, 126);
            this.label10.TabIndex = 89;
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // progressBar11
            // 
            this.progressBar11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.progressBar11.Location = new System.Drawing.Point(228, 153);
            this.progressBar11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar11.Name = "progressBar11";
            this.progressBar11.Size = new System.Drawing.Size(775, 25);
            this.progressBar11.TabIndex = 88;
            // 
            // progressBar12
            // 
            this.progressBar12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.progressBar12.Location = new System.Drawing.Point(848, 25);
            this.progressBar12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar12.Name = "progressBar12";
            this.progressBar12.Size = new System.Drawing.Size(25, 789);
            this.progressBar12.TabIndex = 87;
            // 
            // Player1_5x5_E
            // 
            this.Player1_5x5_E.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.Player1_5x5_E.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Player1_5x5_E.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Player1_5x5_E.Location = new System.Drawing.Point(91, 20);
            this.Player1_5x5_E.Name = "Player1_5x5_E";
            this.Player1_5x5_E.Size = new System.Drawing.Size(83, 30);
            this.Player1_5x5_E.TabIndex = 86;
            // 
            // Player2_5x5_E
            // 
            this.Player2_5x5_E.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.Player2_5x5_E.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Player2_5x5_E.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Player2_5x5_E.Location = new System.Drawing.Point(91, 71);
            this.Player2_5x5_E.Name = "Player2_5x5_E";
            this.Player2_5x5_E.Size = new System.Drawing.Size(83, 30);
            this.Player2_5x5_E.TabIndex = 85;
            // 
            // O_P2
            // 
            this.O_P2.AutoSize = true;
            this.O_P2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.O_P2.Font = new System.Drawing.Font("Microsoft YaHei", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.O_P2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.O_P2.Location = new System.Drawing.Point(28, 61);
            this.O_P2.Name = "O_P2";
            this.O_P2.Size = new System.Drawing.Size(54, 43);
            this.O_P2.TabIndex = 84;
            this.O_P2.Text = "O:";
            // 
            // X_P2
            // 
            this.X_P2.AutoSize = true;
            this.X_P2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.X_P2.Font = new System.Drawing.Font("Microsoft YaHei", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.X_P2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.X_P2.Location = new System.Drawing.Point(35, 9);
            this.X_P2.Name = "X_P2";
            this.X_P2.Size = new System.Drawing.Size(48, 43);
            this.X_P2.TabIndex = 83;
            this.X_P2.Text = "X:";
            // 
            // EMbxGEP_3x3
            // 
            this.EMbxGEP_3x3.Controls.Add(this.gyozteslab3);
            this.EMbxGEP_3x3.Controls.Add(this.menub3);
            this.EMbxGEP_3x3.Controls.Add(this.restartb3);
            this.EMbxGEP_3x3.Controls.Add(this.Player1_3x3_G);
            this.EMbxGEP_3x3.Controls.Add(this.X_P3);
            this.EMbxGEP_3x3.Controls.Add(this.progressBar13);
            this.EMbxGEP_3x3.Controls.Add(this.progressBar14);
            this.EMbxGEP_3x3.Controls.Add(this.progressBar15);
            this.EMbxGEP_3x3.Controls.Add(this.label35);
            this.EMbxGEP_3x3.Controls.Add(this.label38);
            this.EMbxGEP_3x3.Controls.Add(this.label43);
            this.EMbxGEP_3x3.Controls.Add(this.label42);
            this.EMbxGEP_3x3.Controls.Add(this.label41);
            this.EMbxGEP_3x3.Controls.Add(this.label40);
            this.EMbxGEP_3x3.Controls.Add(this.label39);
            this.EMbxGEP_3x3.Controls.Add(this.label37);
            this.EMbxGEP_3x3.Controls.Add(this.label36);
            this.EMbxGEP_3x3.Controls.Add(this.progressBar16);
            this.EMbxGEP_3x3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.EMbxGEP_3x3.Location = new System.Drawing.Point(26, 49);
            this.EMbxGEP_3x3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.EMbxGEP_3x3.Name = "EMbxGEP_3x3";
            this.EMbxGEP_3x3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.EMbxGEP_3x3.Size = new System.Drawing.Size(1100, 900);
            this.EMbxGEP_3x3.TabIndex = 54;
            this.EMbxGEP_3x3.TabStop = false;
            // 
            // gyozteslab3
            // 
            this.gyozteslab3.AutoSize = true;
            this.gyozteslab3.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.gyozteslab3.ForeColor = System.Drawing.Color.White;
            this.gyozteslab3.Location = new System.Drawing.Point(68, 208);
            this.gyozteslab3.Name = "gyozteslab3";
            this.gyozteslab3.Size = new System.Drawing.Size(0, 23);
            this.gyozteslab3.TabIndex = 39;
            this.gyozteslab3.Visible = false;
            // 
            // menub3
            // 
            this.menub3.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.menub3.ForeColor = System.Drawing.Color.Black;
            this.menub3.Location = new System.Drawing.Point(27, 326);
            this.menub3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.menub3.Name = "menub3";
            this.menub3.Size = new System.Drawing.Size(125, 62);
            this.menub3.TabIndex = 38;
            this.menub3.Text = "Menu";
            this.menub3.UseVisualStyleBackColor = true;
            this.menub3.Visible = false;
            this.menub3.Click += new System.EventHandler(this.menub3_Click);
            // 
            // restartb3
            // 
            this.restartb3.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.restartb3.ForeColor = System.Drawing.Color.Black;
            this.restartb3.Location = new System.Drawing.Point(27, 258);
            this.restartb3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.restartb3.Name = "restartb3";
            this.restartb3.Size = new System.Drawing.Size(125, 62);
            this.restartb3.TabIndex = 37;
            this.restartb3.Text = "Restart";
            this.restartb3.UseVisualStyleBackColor = true;
            this.restartb3.Visible = false;
            this.restartb3.Click += new System.EventHandler(this.restartb3_Click);
            // 
            // Player1_3x3_G
            // 
            this.Player1_3x3_G.AutoSize = true;
            this.Player1_3x3_G.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.Player1_3x3_G.Font = new System.Drawing.Font("Microsoft YaHei", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Player1_3x3_G.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Player1_3x3_G.Location = new System.Drawing.Point(95, 36);
            this.Player1_3x3_G.Name = "Player1_3x3_G";
            this.Player1_3x3_G.Size = new System.Drawing.Size(0, 30);
            this.Player1_3x3_G.TabIndex = 36;
            // 
            // X_P3
            // 
            this.X_P3.AutoSize = true;
            this.X_P3.Font = new System.Drawing.Font("Microsoft YaHei", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.X_P3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.X_P3.Location = new System.Drawing.Point(33, 30);
            this.X_P3.Name = "X_P3";
            this.X_P3.Size = new System.Drawing.Size(48, 43);
            this.X_P3.TabIndex = 33;
            this.X_P3.Text = "X:";
            // 
            // progressBar13
            // 
            this.progressBar13.BackColor = System.Drawing.Color.Red;
            this.progressBar13.Location = new System.Drawing.Point(177, 533);
            this.progressBar13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar13.Name = "progressBar13";
            this.progressBar13.Size = new System.Drawing.Size(700, 25);
            this.progressBar13.TabIndex = 32;
            // 
            // progressBar14
            // 
            this.progressBar14.BackColor = System.Drawing.Color.Red;
            this.progressBar14.Location = new System.Drawing.Point(388, 57);
            this.progressBar14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar14.Name = "progressBar14";
            this.progressBar14.Size = new System.Drawing.Size(25, 700);
            this.progressBar14.TabIndex = 31;
            // 
            // progressBar15
            // 
            this.progressBar15.BackColor = System.Drawing.Color.Red;
            this.progressBar15.Location = new System.Drawing.Point(663, 57);
            this.progressBar15.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar15.Name = "progressBar15";
            this.progressBar15.Size = new System.Drawing.Size(25, 700);
            this.progressBar15.TabIndex = 30;
            // 
            // label35
            // 
            this.label35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label35.Font = new System.Drawing.Font("Microsoft YaHei UI", 64.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.SystemColors.Control;
            this.label35.Location = new System.Drawing.Point(184, 75);
            this.label35.Margin = new System.Windows.Forms.Padding(0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(168, 158);
            this.label35.TabIndex = 28;
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label35.Click += new System.EventHandler(this.label35_Click);
            // 
            // label38
            // 
            this.label38.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label38.Font = new System.Drawing.Font("Microsoft YaHei UI", 64.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.ForeColor = System.Drawing.SystemColors.Control;
            this.label38.Location = new System.Drawing.Point(184, 326);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(168, 158);
            this.label38.TabIndex = 27;
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label38.Click += new System.EventHandler(this.label38_Click);
            // 
            // label43
            // 
            this.label43.AccessibleRole = System.Windows.Forms.AccessibleRole.Link;
            this.label43.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label43.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label43.Font = new System.Drawing.Font("Microsoft YaHei UI", 64.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.ForeColor = System.Drawing.SystemColors.Control;
            this.label43.Location = new System.Drawing.Point(719, 583);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(168, 158);
            this.label43.TabIndex = 26;
            this.label43.Tag = "";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label43.Click += new System.EventHandler(this.label43_Click);
            // 
            // label42
            // 
            this.label42.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label42.Font = new System.Drawing.Font("Microsoft YaHei UI", 64.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.ForeColor = System.Drawing.SystemColors.Control;
            this.label42.Location = new System.Drawing.Point(460, 583);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(168, 158);
            this.label42.TabIndex = 25;
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label42.Click += new System.EventHandler(this.label42_Click);
            // 
            // label41
            // 
            this.label41.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label41.Font = new System.Drawing.Font("Microsoft YaHei UI", 64.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.ForeColor = System.Drawing.SystemColors.Control;
            this.label41.Location = new System.Drawing.Point(184, 583);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(168, 158);
            this.label41.TabIndex = 24;
            this.label41.Tag = "";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label41.Click += new System.EventHandler(this.label41_Click);
            // 
            // label40
            // 
            this.label40.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label40.Font = new System.Drawing.Font("Microsoft YaHei UI", 64.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.ForeColor = System.Drawing.SystemColors.Control;
            this.label40.Location = new System.Drawing.Point(719, 326);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(168, 158);
            this.label40.TabIndex = 23;
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label40.Click += new System.EventHandler(this.label40_Click);
            // 
            // label39
            // 
            this.label39.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label39.Font = new System.Drawing.Font("Microsoft YaHei UI", 64.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.SystemColors.Control;
            this.label39.Location = new System.Drawing.Point(460, 326);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(168, 158);
            this.label39.TabIndex = 22;
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label39.Click += new System.EventHandler(this.label39_Click);
            // 
            // label37
            // 
            this.label37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label37.Font = new System.Drawing.Font("Microsoft YaHei UI", 64.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.ForeColor = System.Drawing.SystemColors.Control;
            this.label37.Location = new System.Drawing.Point(719, 75);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(168, 158);
            this.label37.TabIndex = 21;
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label37.Click += new System.EventHandler(this.label37_Click);
            // 
            // label36
            // 
            this.label36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label36.Font = new System.Drawing.Font("Microsoft YaHei UI", 64.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.SystemColors.Control;
            this.label36.Location = new System.Drawing.Point(460, 75);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(168, 158);
            this.label36.TabIndex = 20;
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label36.Click += new System.EventHandler(this.label36_Click);
            // 
            // progressBar16
            // 
            this.progressBar16.BackColor = System.Drawing.Color.Red;
            this.progressBar16.Location = new System.Drawing.Point(187, 279);
            this.progressBar16.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar16.Name = "progressBar16";
            this.progressBar16.Size = new System.Drawing.Size(700, 25);
            this.progressBar16.TabIndex = 17;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.gyozteslab4);
            this.groupBox3.Controls.Add(this.menub4);
            this.groupBox3.Controls.Add(this.restartb4);
            this.groupBox3.Controls.Add(this.progressBar17);
            this.groupBox3.Controls.Add(this.progressBar18);
            this.groupBox3.Controls.Add(this.progressBar19);
            this.groupBox3.Controls.Add(this.progressBar20);
            this.groupBox3.Controls.Add(this.progressBar21);
            this.groupBox3.Controls.Add(this.progressBar22);
            this.groupBox3.Controls.Add(this.label68);
            this.groupBox3.Controls.Add(this.label67);
            this.groupBox3.Controls.Add(this.label66);
            this.groupBox3.Controls.Add(this.label65);
            this.groupBox3.Controls.Add(this.label64);
            this.groupBox3.Controls.Add(this.label63);
            this.groupBox3.Controls.Add(this.label62);
            this.groupBox3.Controls.Add(this.label61);
            this.groupBox3.Controls.Add(this.label60);
            this.groupBox3.Controls.Add(this.label59);
            this.groupBox3.Controls.Add(this.label58);
            this.groupBox3.Controls.Add(this.label57);
            this.groupBox3.Controls.Add(this.label56);
            this.groupBox3.Controls.Add(this.label55);
            this.groupBox3.Controls.Add(this.label54);
            this.groupBox3.Controls.Add(this.label53);
            this.groupBox3.Controls.Add(this.label52);
            this.groupBox3.Controls.Add(this.label51);
            this.groupBox3.Controls.Add(this.label50);
            this.groupBox3.Controls.Add(this.label49);
            this.groupBox3.Controls.Add(this.label47);
            this.groupBox3.Controls.Add(this.label46);
            this.groupBox3.Controls.Add(this.label48);
            this.groupBox3.Controls.Add(this.label45);
            this.groupBox3.Controls.Add(this.label44);
            this.groupBox3.Controls.Add(this.progressBar23);
            this.groupBox3.Controls.Add(this.progressBar24);
            this.groupBox3.Controls.Add(this.Player1_5x5_G);
            this.groupBox3.Controls.Add(this.X_P4);
            this.groupBox3.Location = new System.Drawing.Point(26, 49);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1100, 900);
            this.groupBox3.TabIndex = 55;
            this.groupBox3.TabStop = false;
            // 
            // gyozteslab4
            // 
            this.gyozteslab4.AutoSize = true;
            this.gyozteslab4.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.gyozteslab4.ForeColor = System.Drawing.Color.White;
            this.gyozteslab4.Location = new System.Drawing.Point(104, 228);
            this.gyozteslab4.Name = "gyozteslab4";
            this.gyozteslab4.Size = new System.Drawing.Size(23, 23);
            this.gyozteslab4.TabIndex = 160;
            this.gyozteslab4.Text = "w";
            this.gyozteslab4.Visible = false;
            // 
            // menub4
            // 
            this.menub4.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.menub4.ForeColor = System.Drawing.Color.Black;
            this.menub4.Location = new System.Drawing.Point(78, 336);
            this.menub4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.menub4.Name = "menub4";
            this.menub4.Size = new System.Drawing.Size(125, 62);
            this.menub4.TabIndex = 159;
            this.menub4.Text = "Menu";
            this.menub4.UseVisualStyleBackColor = true;
            this.menub4.Visible = false;
            this.menub4.Click += new System.EventHandler(this.menub4_Click);
            // 
            // restartb4
            // 
            this.restartb4.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.restartb4.ForeColor = System.Drawing.Color.Black;
            this.restartb4.Location = new System.Drawing.Point(78, 269);
            this.restartb4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.restartb4.Name = "restartb4";
            this.restartb4.Size = new System.Drawing.Size(125, 62);
            this.restartb4.TabIndex = 158;
            this.restartb4.Text = "Restart";
            this.restartb4.UseVisualStyleBackColor = true;
            this.restartb4.Visible = false;
            this.restartb4.Click += new System.EventHandler(this.restartb4_Click);
            // 
            // progressBar17
            // 
            this.progressBar17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.progressBar17.Location = new System.Drawing.Point(233, 681);
            this.progressBar17.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar17.Name = "progressBar17";
            this.progressBar17.Size = new System.Drawing.Size(775, 25);
            this.progressBar17.TabIndex = 157;
            // 
            // progressBar18
            // 
            this.progressBar18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.progressBar18.Location = new System.Drawing.Point(233, 515);
            this.progressBar18.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar18.Name = "progressBar18";
            this.progressBar18.Size = new System.Drawing.Size(775, 25);
            this.progressBar18.TabIndex = 156;
            // 
            // progressBar19
            // 
            this.progressBar19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.progressBar19.Location = new System.Drawing.Point(233, 348);
            this.progressBar19.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar19.Name = "progressBar19";
            this.progressBar19.Size = new System.Drawing.Size(775, 25);
            this.progressBar19.TabIndex = 155;
            // 
            // progressBar20
            // 
            this.progressBar20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.progressBar20.Location = new System.Drawing.Point(367, 51);
            this.progressBar20.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar20.Name = "progressBar20";
            this.progressBar20.Size = new System.Drawing.Size(25, 789);
            this.progressBar20.TabIndex = 154;
            // 
            // progressBar21
            // 
            this.progressBar21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.progressBar21.Location = new System.Drawing.Point(529, 52);
            this.progressBar21.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar21.Name = "progressBar21";
            this.progressBar21.Size = new System.Drawing.Size(25, 789);
            this.progressBar21.TabIndex = 153;
            // 
            // progressBar22
            // 
            this.progressBar22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.progressBar22.Location = new System.Drawing.Point(691, 52);
            this.progressBar22.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar22.Name = "progressBar22";
            this.progressBar22.Size = new System.Drawing.Size(25, 789);
            this.progressBar22.TabIndex = 152;
            // 
            // label68
            // 
            this.label68.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label68.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label68.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label68.ForeColor = System.Drawing.SystemColors.Control;
            this.label68.Location = new System.Drawing.Point(884, 715);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(125, 126);
            this.label68.TabIndex = 151;
            this.label68.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label68.Click += new System.EventHandler(this.label68_Click);
            // 
            // label67
            // 
            this.label67.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label67.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label67.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label67.ForeColor = System.Drawing.SystemColors.Control;
            this.label67.Location = new System.Drawing.Point(721, 715);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(125, 126);
            this.label67.TabIndex = 150;
            this.label67.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label67.Click += new System.EventHandler(this.label67_Click);
            // 
            // label66
            // 
            this.label66.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label66.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label66.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label66.ForeColor = System.Drawing.SystemColors.Control;
            this.label66.Location = new System.Drawing.Point(560, 715);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(125, 126);
            this.label66.TabIndex = 149;
            this.label66.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label66.Click += new System.EventHandler(this.label66_Click);
            // 
            // label65
            // 
            this.label65.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label65.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label65.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label65.ForeColor = System.Drawing.SystemColors.Control;
            this.label65.Location = new System.Drawing.Point(399, 715);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(125, 126);
            this.label65.TabIndex = 148;
            this.label65.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label65.Click += new System.EventHandler(this.label65_Click);
            // 
            // label64
            // 
            this.label64.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label64.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label64.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label64.ForeColor = System.Drawing.SystemColors.Control;
            this.label64.Location = new System.Drawing.Point(236, 715);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(125, 126);
            this.label64.TabIndex = 147;
            this.label64.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label64.Click += new System.EventHandler(this.label64_Click);
            // 
            // label63
            // 
            this.label63.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label63.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label63.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label63.ForeColor = System.Drawing.SystemColors.Control;
            this.label63.Location = new System.Drawing.Point(884, 548);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(125, 126);
            this.label63.TabIndex = 146;
            this.label63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label63.Click += new System.EventHandler(this.label63_Click);
            // 
            // label62
            // 
            this.label62.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label62.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label62.ForeColor = System.Drawing.SystemColors.Control;
            this.label62.Location = new System.Drawing.Point(721, 548);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(125, 126);
            this.label62.TabIndex = 145;
            this.label62.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label62.Click += new System.EventHandler(this.label62_Click);
            // 
            // label61
            // 
            this.label61.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label61.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label61.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label61.ForeColor = System.Drawing.SystemColors.Control;
            this.label61.Location = new System.Drawing.Point(560, 548);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(125, 126);
            this.label61.TabIndex = 144;
            this.label61.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label61.Click += new System.EventHandler(this.label61_Click);
            // 
            // label60
            // 
            this.label60.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label60.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label60.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label60.ForeColor = System.Drawing.SystemColors.Control;
            this.label60.Location = new System.Drawing.Point(399, 548);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(125, 126);
            this.label60.TabIndex = 143;
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label60.Click += new System.EventHandler(this.label60_Click);
            // 
            // label59
            // 
            this.label59.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label59.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label59.ForeColor = System.Drawing.SystemColors.Control;
            this.label59.Location = new System.Drawing.Point(236, 548);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(125, 126);
            this.label59.TabIndex = 142;
            this.label59.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label59.Click += new System.EventHandler(this.label59_Click);
            // 
            // label58
            // 
            this.label58.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label58.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label58.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label58.ForeColor = System.Drawing.SystemColors.Control;
            this.label58.Location = new System.Drawing.Point(884, 380);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(125, 126);
            this.label58.TabIndex = 141;
            this.label58.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label58.Click += new System.EventHandler(this.label58_Click);
            // 
            // label57
            // 
            this.label57.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label57.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label57.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label57.ForeColor = System.Drawing.SystemColors.Control;
            this.label57.Location = new System.Drawing.Point(721, 380);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(125, 126);
            this.label57.TabIndex = 140;
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label57.Click += new System.EventHandler(this.label57_Click);
            // 
            // label56
            // 
            this.label56.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label56.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label56.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label56.ForeColor = System.Drawing.SystemColors.Control;
            this.label56.Location = new System.Drawing.Point(560, 380);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(125, 126);
            this.label56.TabIndex = 139;
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label56.Click += new System.EventHandler(this.label56_Click);
            // 
            // label55
            // 
            this.label55.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label55.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label55.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label55.ForeColor = System.Drawing.SystemColors.Control;
            this.label55.Location = new System.Drawing.Point(399, 380);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(125, 126);
            this.label55.TabIndex = 138;
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label55.Click += new System.EventHandler(this.label55_Click);
            // 
            // label54
            // 
            this.label54.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label54.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label54.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label54.ForeColor = System.Drawing.SystemColors.Control;
            this.label54.Location = new System.Drawing.Point(236, 379);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(125, 126);
            this.label54.TabIndex = 137;
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label54.Click += new System.EventHandler(this.label54_Click);
            // 
            // label53
            // 
            this.label53.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label53.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label53.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label53.ForeColor = System.Drawing.SystemColors.Control;
            this.label53.Location = new System.Drawing.Point(884, 215);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(125, 126);
            this.label53.TabIndex = 136;
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label53.Click += new System.EventHandler(this.label53_Click);
            // 
            // label52
            // 
            this.label52.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label52.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label52.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label52.ForeColor = System.Drawing.SystemColors.Control;
            this.label52.Location = new System.Drawing.Point(721, 215);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(125, 126);
            this.label52.TabIndex = 135;
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label52.Click += new System.EventHandler(this.label52_Click);
            // 
            // label51
            // 
            this.label51.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label51.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label51.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label51.ForeColor = System.Drawing.SystemColors.Control;
            this.label51.Location = new System.Drawing.Point(560, 215);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(125, 126);
            this.label51.TabIndex = 134;
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label51.Click += new System.EventHandler(this.label51_Click);
            // 
            // label50
            // 
            this.label50.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label50.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label50.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label50.ForeColor = System.Drawing.SystemColors.Control;
            this.label50.Location = new System.Drawing.Point(399, 215);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(125, 126);
            this.label50.TabIndex = 133;
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label50.Click += new System.EventHandler(this.label50_Click);
            // 
            // label49
            // 
            this.label49.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label49.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label49.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label49.ForeColor = System.Drawing.SystemColors.Control;
            this.label49.Location = new System.Drawing.Point(236, 215);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(125, 126);
            this.label49.TabIndex = 132;
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label49.Click += new System.EventHandler(this.label49_Click);
            // 
            // label47
            // 
            this.label47.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label47.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label47.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label47.ForeColor = System.Drawing.SystemColors.Control;
            this.label47.Location = new System.Drawing.Point(721, 52);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(125, 126);
            this.label47.TabIndex = 131;
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label47.Click += new System.EventHandler(this.label47_Click);
            // 
            // label46
            // 
            this.label46.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label46.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label46.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label46.ForeColor = System.Drawing.SystemColors.Control;
            this.label46.Location = new System.Drawing.Point(560, 52);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(125, 126);
            this.label46.TabIndex = 130;
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label46.Click += new System.EventHandler(this.label46_Click);
            // 
            // label48
            // 
            this.label48.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label48.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label48.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label48.ForeColor = System.Drawing.SystemColors.Control;
            this.label48.Location = new System.Drawing.Point(884, 52);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(125, 126);
            this.label48.TabIndex = 129;
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label48.Click += new System.EventHandler(this.label48_Click);
            // 
            // label45
            // 
            this.label45.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label45.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label45.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label45.ForeColor = System.Drawing.Color.White;
            this.label45.Location = new System.Drawing.Point(399, 51);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(125, 126);
            this.label45.TabIndex = 128;
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label45.Click += new System.EventHandler(this.label45_Click);
            // 
            // label44
            // 
            this.label44.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label44.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label44.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label44.ForeColor = System.Drawing.SystemColors.Control;
            this.label44.Location = new System.Drawing.Point(236, 51);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(125, 126);
            this.label44.TabIndex = 127;
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label44.Click += new System.EventHandler(this.label44_Click);
            // 
            // progressBar23
            // 
            this.progressBar23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.progressBar23.Location = new System.Drawing.Point(233, 185);
            this.progressBar23.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar23.Name = "progressBar23";
            this.progressBar23.Size = new System.Drawing.Size(775, 25);
            this.progressBar23.TabIndex = 126;
            // 
            // progressBar24
            // 
            this.progressBar24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.progressBar24.Location = new System.Drawing.Point(853, 51);
            this.progressBar24.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar24.Name = "progressBar24";
            this.progressBar24.Size = new System.Drawing.Size(25, 789);
            this.progressBar24.TabIndex = 125;
            // 
            // Player1_5x5_G
            // 
            this.Player1_5x5_G.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.Player1_5x5_G.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Player1_5x5_G.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Player1_5x5_G.Location = new System.Drawing.Point(120, 31);
            this.Player1_5x5_G.Name = "Player1_5x5_G";
            this.Player1_5x5_G.Size = new System.Drawing.Size(83, 30);
            this.Player1_5x5_G.TabIndex = 124;
            // 
            // X_P4
            // 
            this.X_P4.AutoSize = true;
            this.X_P4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.X_P4.Font = new System.Drawing.Font("Microsoft YaHei", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.X_P4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.X_P4.Location = new System.Drawing.Point(64, 20);
            this.X_P4.Name = "X_P4";
            this.X_P4.Size = new System.Drawing.Size(48, 43);
            this.X_P4.TabIndex = 123;
            this.X_P4.Text = "X:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.ClientSize = new System.Drawing.Size(1924, 1055);
            this.Controls.Add(this.kezolap);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.EmbxEmb_3x3);
            this.Controls.Add(this.EMbxGEP_3x3);
            this.Controls.Add(this.EmbxEmb_5x5);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.kezolap.ResumeLayout(false);
            this.kezolap.PerformLayout();
            this.EmbxEmb_3x3.ResumeLayout(false);
            this.EmbxEmb_3x3.PerformLayout();
            this.EmbxEmb_5x5.ResumeLayout(false);
            this.EmbxEmb_5x5.PerformLayout();
            this.EMbxGEP_3x3.ResumeLayout(false);
            this.EMbxGEP_3x3.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label Cim;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label O;
        private System.Windows.Forms.Label X;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox kezolap;
        private System.Windows.Forms.GroupBox EmbxEmb_3x3;
        private System.Windows.Forms.Label gyozteslab1;
        private System.Windows.Forms.Button menub1;
        private System.Windows.Forms.Button restartb1;
        private System.Windows.Forms.Label Player1_3x3_E;
        private System.Windows.Forms.Label Player2_3x3_E;
        private System.Windows.Forms.Label O_p1;
        private System.Windows.Forms.Label X_P1;
        private System.Windows.Forms.ProgressBar progressBar4;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.ProgressBar progressBar3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ProgressBar progressBar2;
        private System.Windows.Forms.GroupBox EmbxEmb_5x5;
        private System.Windows.Forms.Label gyozteslab2;
        private System.Windows.Forms.Button menub2;
        private System.Windows.Forms.Button restartb2;
        private System.Windows.Forms.ProgressBar progressBar9;
        private System.Windows.Forms.ProgressBar progressBar8;
        private System.Windows.Forms.ProgressBar progressBar7;
        private System.Windows.Forms.ProgressBar progressBar6;
        private System.Windows.Forms.ProgressBar progressBar5;
        private System.Windows.Forms.ProgressBar progressBar10;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ProgressBar progressBar11;
        private System.Windows.Forms.ProgressBar progressBar12;
        private System.Windows.Forms.Label Player1_5x5_E;
        private System.Windows.Forms.Label Player2_5x5_E;
        private System.Windows.Forms.Label O_P2;
        private System.Windows.Forms.Label X_P2;
        private System.Windows.Forms.GroupBox EMbxGEP_3x3;
        private System.Windows.Forms.Label gyozteslab3;
        private System.Windows.Forms.Button menub3;
        private System.Windows.Forms.Button restartb3;
        private System.Windows.Forms.Label Player1_3x3_G;
        private System.Windows.Forms.Label X_P3;
        private System.Windows.Forms.ProgressBar progressBar13;
        private System.Windows.Forms.ProgressBar progressBar14;
        private System.Windows.Forms.ProgressBar progressBar15;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.ProgressBar progressBar16;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label gyozteslab4;
        private System.Windows.Forms.Button menub4;
        private System.Windows.Forms.Button restartb4;
        private System.Windows.Forms.ProgressBar progressBar17;
        private System.Windows.Forms.ProgressBar progressBar18;
        private System.Windows.Forms.ProgressBar progressBar19;
        private System.Windows.Forms.ProgressBar progressBar20;
        private System.Windows.Forms.ProgressBar progressBar21;
        private System.Windows.Forms.ProgressBar progressBar22;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.ProgressBar progressBar23;
        private System.Windows.Forms.ProgressBar progressBar24;
        private System.Windows.Forms.Label Player1_5x5_G;
        private System.Windows.Forms.Label X_P4;
    }
}

