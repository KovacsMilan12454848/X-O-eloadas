﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace GRobbox
{
    public partial class Form1 : Form
    {
        public System.Windows.Forms.Label[,] labels_3x3;
        public System.Windows.Forms.Label[,] labels_3x3_E;
        public System.Windows.Forms.Label[,] labels_5x5;
        public System.Windows.Forms.Label[,] labels_5x5_E;
        public Form1()
        {
            InitializeComponent();
            
            labels_3x3 = new System.Windows.Forms.Label[,]
            {
                { label35, label36, label37 },
                { label38, label39, label40 },
                { label41, label42, label43 }
            };
            labels_3x3_E = new System.Windows.Forms.Label[,]
            {
                { label1, label2, label3 },
                { label4, label5, label6 },
                { label7, label8, label9 }
            };


            labels_5x5_E = new System.Windows.Forms.Label[,]
            {
                    { label10, label11, label12, label13, label14 },
                    { label15, label16, label17, label18, label19 },
                    { label20, label21, label22, label23, label24 },
                    { label25, label26, label27, label28, label29 },
                    { label30, label31, label32, label33, label34 }
            };
            labels_5x5 = new System.Windows.Forms.Label[,]
            {
                 { label44, label45, label46, label47, label48 },
                 { label49, label50, label51, label52, label53 },
                 { label54, label55, label56, label57, label58 },
                 { label59, label60, label61, label62, label63 },
                 { label64, label65, label66, label67, label68 }
            };


        }

        Random rnd = new Random();
        string[,] board_3x3 = { { "1", "2", "3" }, { "4", "5", "6" }, { "7", "8", "9" } };
        string[,] board_5x5 = { { "1", "2", "3","4", "5" },{ "6", "7", "8","9", "10" },{ "11", "12", "13","14", "15" },{ "16", "17", "18","19", "20" },{ "21", "22", "23","24", "25" }};

        int num = 0;
        bool vanNyertes = false;

        public void visible()
        {
            kezolap.Visible = true;
            EmbxEmb_3x3.Visible = false;
            EmbxEmb_5x5.Visible = false;
            groupBox3.Visible = false;
            EMbxGEP_3x3.Visible=false;
        }

        //          CHECK
        //---------------------------------------------------------------------------------------------------------------------------------------

        // Ember x Ember 
        public string Check()
        {


            if (num % 2 == 0)
            {
                num++;

                return "X";
            }
            else
            {
                num++;

                return "O";
            }
            // megnez van e nyertes     
        }


        public void Check_Gep_3x5()
        {
            int retries = 0;
            if (radioButton1.Checked == true && radioButton3.Checked == true)
            {
                

                while (retries < 10)
                {
                    int ind = rnd.Next(3);
                    int ind2 = rnd.Next(3);

                    if (board_3x3[ind, ind2] != "X" && board_3x3[ind, ind2] != "O")
                    {
                        board_3x3[ind, ind2] = "X";
                        labels_3x3[ind, ind2].Text = "X";

                        num++;
                        break;
                    }
                    retries++;
                }
            }
            if (radioButton2.Checked == true && radioButton3.Checked == true)
            {
                while (retries < 25)
                {

                    int tomb1 = rnd.Next(5);
                    int tomb2 = rnd.Next(5);
                    if (board_5x5[tomb1, tomb2] != "X" && board_5x5[tomb1, tomb2] != "O")
                    {
                        board_5x5[tomb1, tomb2] = "X";
                        labels_5x5[tomb1, tomb2].Text = "X";

                        num++;
                        break;
                    }
                    retries++;
                }
            }


        }
        

        //          RESTART
        //---------------------------------------------------------------------------------------------------------------------------------------
        public void resetgame()
        {
            if (radioButton1.Checked == true && radioButton4.Checked == true)
            {
                foreach (System.Windows.Forms.Label i in labels_3x3_E)
                {
                    i.Text = "";
                }
                num = 0;
                vanNyertes = false;

                board_3x3 = new string[,]
                {
                { "1", "2", "3" },
                { "4", "5", "6" },
                { "7", "8", "9" }
                };
                restartb1.Visible = false;
                menub1.Visible = false;
                gyozteslab1.Visible = false;
            }
            if (radioButton1.Checked == true && radioButton3.Checked == true)
            {
                foreach (System.Windows.Forms.Label i in labels_3x3)
                {
                    i.Text = "";
                }
                num = 0;
                vanNyertes = false;

                board_3x3 = new string[,]
                {
                { "1", "2", "3" },
                { "4", "5", "6" },
                { "7", "8", "9" }
                };
                restartb3.Visible = false;
                menub3.Visible = false;
                gyozteslab3.Visible = false;
            }
        }
        public void menu()
        {
            if (radioButton1.Checked == true && radioButton4.Checked == true)
            {
                gyozteslab1.Visible = true;
                restartb1.Visible = true;
                menub1.Visible = true;
            }
            if (radioButton1.Checked == true && radioButton3.Checked == true)
            {
                gyozteslab3.Visible = true;
                restartb3.Visible = true;
                menub3.Visible = true;

            }

        }
        //                           5x5
        //===============================================================

        public void resetgame2()
        {
            if (radioButton2.Checked == true && radioButton4.Checked == true)
            {
                foreach (System.Windows.Forms.Label i in labels_5x5_E)
                {
                    i.Text = "";
                }
                num = 0;
                vanNyertes = false;



                board_5x5 = new string[,]{
                            { "1", "2", "3","4", "5" },
                            { "6", "7", "8","9", "10" },
                            { "11", "12", "13","14", "15" },
                            { "16", "17", "18","19", "20" },
                            { "21", "22", "23","24", "25" }
                };
                restartb2.Visible = false;
                menub2.Visible = false;
                gyozteslab2.Visible = false;
            }
            if (radioButton2.Checked == true && radioButton3.Checked == true)
            {
                foreach (System.Windows.Forms.Label i in labels_5x5)
                {
                    i.Text = "";
                }
                num = 0;
                vanNyertes = false;



                board_5x5 = new string[,]{
                            { "1", "2", "3","4", "5" },
                            { "6", "7", "8","9", "10" },
                            { "11", "12", "13","14", "15" },
                            { "16", "17", "18","19", "20" },
                            { "21", "22", "23","24", "25" }
                };
                restartb4.Visible = false;
                menub4.Visible = false;
                gyozteslab4.Visible = false;
            }
        }




        public void menu2()
        {
            if (radioButton2.Checked == true && radioButton4.Checked == true)
            {
                gyozteslab2.Visible = true;
                restartb2.Visible = true;
                menub2.Visible = true;
            }
            if (radioButton2.Checked == true && radioButton3.Checked == true)
            {
                gyozteslab4.Visible = true;
                restartb4.Visible = true;
                menub4.Visible = true;
            }

        }


        //                     NYERÉSSI LEHETŐSÉGEK
        //---------------------------------------------------------------------------------------------------------------------------------------



        // EMBER x EMBER 3x3  / EMBER x GÉP  3x3
        public void VanNyertes_3x3()
        {
            if (num > 3)
            {


                // ---
                for (int i = 0; i <= 2; i++)
                {
                    if (board_3x3[i, 0] == board_3x3[i, 1] && board_3x3[i, 1] == board_3x3[i, 2])
                    {
                        gyozteslab1.Text = $"A Győztes: {board_3x3[i, 0]}";
                        gyozteslab3.Text = $"A Győztes: {board_3x3[i, 0]}";
                        menu();
                        vanNyertes = true;

                    }

                }
                // |
                for (int i = 0; i <= 2; i++)
                {
                    if (board_3x3[0, i] == board_3x3[1, i] && board_3x3[2, i] == board_3x3[1, i])
                    {
                        gyozteslab1.Text = $"A Győztes: {board_3x3[0, i]}";
                        gyozteslab3.Text = $"A Győztes: {board_3x3[0, i]}";
                        menu();
                        vanNyertes = true;

                    }

                }
                // \, /
                if (board_3x3[0, 0] == board_3x3[1, 1] && board_3x3[2, 2] == board_3x3[1, 1])
                {

                    gyozteslab1.Text = $"A Győztes: {board_3x3[0, 0]}";
                    gyozteslab3.Text = $"A Győztes: {board_3x3[0, 0]}";
                    menu();
                    vanNyertes = true;
                }

                if (board_3x3[0, 2] == board_3x3[1, 1] && board_3x3[2, 0] == board_3x3[1, 1])
                {
                    gyozteslab1.Text = $"A Győztes: {board_3x3[0, 2]}";
                    gyozteslab3.Text = $"A Győztes: {board_3x3[0, 2]}";
                    menu();
                    vanNyertes = true;

                }
                if (num == 9 && !vanNyertes)
                {
                    gyozteslab1.Text = $"Döntetlen";  // Display "Döntetlen" for a tie
                    gyozteslab3.Text = $"Döntetlen";
                    menu();
                }

            }

        }

        // EMBER x EMBER 5x5  / EMBER x GÉP  5x5
        public void VanNyertes_5x5()
        {


            if (num > 5)
            {


                // ---
                for (int i = 0; i < 5; i++)
                {
                    if (board_5x5[i, 0] == board_5x5[i, 1] && board_5x5[i, 1] == board_5x5[i, 2] && board_5x5[i, 2] == board_5x5[i, 3] && board_5x5[i, 3] == board_5x5[i, 4])
                    {
                        gyozteslab2.Text = $"A Győztes: {board_5x5[i, 0]}";
                        gyozteslab4.Text = $"A Győztes: {board_5x5[i, 0]}";
                        menu2();
                        vanNyertes = true;

                    }

                }
                // |
                for (int i = 0; i < 5; i++)
                {
                    if (board_5x5[0, i] == board_5x5[1, i] && board_5x5[1, i] == board_5x5[2, i] && board_5x5[2, i] == board_5x5[3, i] && board_5x5[3, i] == board_5x5[4, i])
                    {
                        gyozteslab2.Text = $"A Győztes: {board_5x5[0, i]}";
                        gyozteslab4.Text = $"A Győztes: {board_5x5[0, i]}";
                        menu2();
                        vanNyertes = true;

                    }

                }
                // \, /
                if (board_5x5[0, 0] == board_5x5[1, 1] && board_5x5[1, 1] == board_5x5[2, 2] && board_5x5[2, 2] == board_5x5[3, 3] && board_5x5[3, 3] == board_5x5[4, 4])
                {
                    gyozteslab2.Text = $"A Győztes: {board_5x5[0, 0]}";
                    gyozteslab4.Text = $"A Győztes: {board_5x5[0, 0]}";
                    menu2();
                    vanNyertes = true;
                }

                if (board_5x5[0, 4] == board_5x5[1, 3] && board_5x5[1, 3] == board_5x5[2, 2] && board_5x5[2, 2] == board_5x5[3, 1] && board_5x5[3, 1] == board_5x5[4, 0])
                {
                    gyozteslab2.Text = $"A Győztes: {board_5x5[0, 4]}";
                    gyozteslab4.Text = $"A Győztes: {board_5x5[0, 4]}";
                    menu2();
                    vanNyertes = true;
                }


                if (num == 25 && vanNyertes == false)
                {
                    label1.Text = $"Döntetlen";
                    gyozteslab4.Text = $"Döntetlen";
                    menu2(); 

                }

            }

        }




        //                     GUI-s  FELÜLET
        //---------------------------------------------------------------------------------------------------------------------------------------



        //                     KEZELŐ RÉSZ
        //---------------------------------------------------------------------------------------------------------------------------------------

        private void Form1_Load(object sender, EventArgs e)
        {
            visible();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            //SQL szerver
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //STEAR GOMB
            if (textBox1.Text != "" && textBox2.Text != "" && radioButton1.Checked == true && radioButton4.Checked == true)
            {
                //  EMBER x EMBER /3x3
                kezolap.Visible = false;
                EmbxEmb_3x3.Visible = true;
                Player1_3x3_E.Text= textBox1.Text;
                Player2_3x3_E.Text = textBox2.Text;
                
            }
            if (textBox1.Text != "" && textBox2.Text != "" && radioButton2.Checked == true && radioButton4.Checked == true)
            {
                //  EMBER x EMBER /3x3
                kezolap.Visible = false;
                EmbxEmb_5x5.Visible = true;
                Player1_5x5_E.Text = textBox1.Text;
                Player2_5x5_E.Text = textBox2.Text;
                
            }
            if (textBox1.Text != "" && radioButton1.Checked == true && radioButton3.Checked == true)
            {
                //      EMBER x GÉP /3x3
                kezolap.Visible = false;
                EMbxGEP_3x3.Visible = true;
                Player1_3x3_G.Text = textBox1.Text;
                if (textBox2.Text != "") textBox2.Text = "";



            }


            if (textBox1.Text != "" && radioButton2.Checked == true && radioButton3.Checked == true)
            {
                //      EMBER x GÉP /5x5
                kezolap.Visible = false;
                groupBox3.Visible = true;
                Player1_5x5_E.Text = textBox1.Text;
                if (textBox2.Text != "") textBox2.Text = "";

            }

        }



        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            //  EMBER
            textBox2.Visible = true;
            O.Visible = true;

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            // GÉP
            textBox2.Visible = false;
            O.Visible = false;


        }




        //                     LABEL KEZELŐ RÉSZ
        //---------------------------------------------------------------------------------------------------------------------------------------


        //                  EMB_x_EMB 3x3
        //-------------------------------------------------------------------------------------------------------------------------------------------
        private void label1_Click(object sender, EventArgs e)
        {
            if (label1.Text == "" && vanNyertes != true)
            {

                label1.Text = Check();
                board_3x3[0, 0] = label1.Text;
                VanNyertes_3x3();


            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

            if (label2.Text == "" && vanNyertes != true)
            {

                label2.Text = Check();
                board_3x3[0, 1] = label2.Text;
                VanNyertes_3x3();


            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

            if (label3.Text == "" && vanNyertes != true)
            {

                label3.Text = Check();
                board_3x3[0, 2] = label3.Text;
                VanNyertes_3x3();


            }
        }

        private void label4_Click(object sender, EventArgs e)
        {
            if (label4.Text == "" && vanNyertes != true)
            {

                label4.Text = Check();
                board_3x3[1, 0] = label4.Text;
                VanNyertes_3x3();


            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

            if (label5.Text == "" && vanNyertes != true)
            {

                label5.Text = Check();
                board_3x3[1, 1] = label5.Text;
                VanNyertes_3x3();


            }
        }

        private void label6_Click(object sender, EventArgs e)
        {
            if (label6.Text == "" && vanNyertes != true)
            {

                label6.Text = Check();
                board_3x3[1, 2] = label6.Text;
                VanNyertes_3x3();


            }
        }

        private void label7_Click(object sender, EventArgs e)
        {

            if (label7.Text == "" && vanNyertes != true)
            {

                label7.Text = Check();
                board_3x3[2, 0] = label7.Text;
                VanNyertes_3x3();


            }
        }

        private void label8_Click(object sender, EventArgs e)
        {

            if (label8.Text == "" && vanNyertes != true)
            {

                label8.Text = Check();
                board_3x3[2, 1] = label8.Text;
                VanNyertes_3x3();


            }
        }

        private void label9_Click(object sender, EventArgs e)
        {
            if (label9.Text == "" && vanNyertes != true)
            {

                label9.Text = Check();
                board_3x3[2, 2] = label9.Text;
                VanNyertes_3x3();


            }
        }

        private void restartb_Click(object sender, EventArgs e)
        {
            resetgame();


        }

        private void menub1_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            kezolap.Visible = true;
            EmbxEmb_3x3.Visible = false;
            resetgame();

        }


        //                          EMB_x_EMB 5x5
        //-------------------------------------------------------------------------------------------------------------------------------------------


        //                               gyozteslab2
        private void label10_Click(object sender, EventArgs e)
        {
            if (label10.Text == "" && vanNyertes != true)
            {

                label10.Text = Check();
                board_5x5[0, 0] = label10.Text;
                VanNyertes_5x5();

            }
        }

        private void label11_Click(object sender, EventArgs e)
        {
            if (label11.Text == "" && vanNyertes != true)
            {

                label11.Text = Check();
                board_5x5[0, 1] = label11.Text;
                VanNyertes_5x5();

            }
        }

        private void label12_Click(object sender, EventArgs e)
        {
            if (label12.Text == "" && vanNyertes != true)
            {

                label12.Text = Check();
                board_5x5[0, 2] = label12.Text;
                VanNyertes_5x5();

            }
        }

        private void label13_Click(object sender, EventArgs e)
        {
            if (label13.Text == "" && vanNyertes != true)
            {

                label13.Text = Check();
                board_5x5[0, 3] = label13.Text;
                VanNyertes_5x5();

            }
        }

        private void label14_Click(object sender, EventArgs e)
        {
            if (label14.Text == "" && vanNyertes != true)
            {

                label14.Text = Check();
                board_5x5[0, 4] = label14.Text;
                VanNyertes_5x5();

            }
        }

        private void label15_Click(object sender, EventArgs e)
        {
            if (label15.Text == "" && vanNyertes != true)
            {

                label15.Text = Check();
                board_5x5[1, 0] = label15.Text;
                VanNyertes_5x5();

            }
        }

        private void label16_Click(object sender, EventArgs e)
        {
            if (label16.Text == "" && vanNyertes != true)
            {

                label16.Text = Check();
                board_5x5[1, 1] = label16.Text;
                VanNyertes_5x5();

            }
        }

        private void label17_Click(object sender, EventArgs e)
        {
            if (label17.Text == "" && vanNyertes != true)
            {

                label17.Text = Check();
                board_5x5[1, 2] = label17.Text;
                VanNyertes_5x5();

            }
        }

        private void label18_Click(object sender, EventArgs e)
        {
            if (label18.Text == "" && vanNyertes != true)
            {

                label18.Text = Check();
                board_5x5[1, 3] = label18.Text;
                VanNyertes_5x5();

            }
        }

        private void label19_Click(object sender, EventArgs e)
        {
            if (label19.Text == "" && vanNyertes != true)
            {

                label19.Text = Check();
                board_5x5[1, 4] = label19.Text;
                VanNyertes_5x5();

            }
        }

        private void label20_Click(object sender, EventArgs e)
        {
            if (label20.Text == "" && vanNyertes != true)
            {

                label20.Text = Check();
                board_5x5[2, 0] = label20.Text;
                VanNyertes_5x5();

            }
        }

        private void label21_Click(object sender, EventArgs e)
        {
            if (label21.Text == "" && vanNyertes != true)
            {

                label21.Text = Check();
                board_5x5[2, 1] = label21.Text;
                VanNyertes_5x5();

            }
        }

        private void label22_Click(object sender, EventArgs e)
        {
            if (label22.Text == "" && vanNyertes != true)
            {

                label22.Text = Check();
                board_5x5[2, 2] = label22.Text;
                VanNyertes_5x5();

            }
        }

        private void label23_Click(object sender, EventArgs e)
        {
            if (label23.Text == "" && vanNyertes != true)
            {

                label23.Text = Check();
                board_5x5[2, 3] = label23.Text;
                VanNyertes_5x5();

            }
        }

        private void label24_Click(object sender, EventArgs e)
        {
            if (label24.Text == "" && vanNyertes != true)
            {

                label24.Text = Check();
                board_5x5[2, 4] = label24.Text;
                VanNyertes_5x5();

            }
        }

        private void label25_Click(object sender, EventArgs e)
        {
            if (label25.Text == "" && vanNyertes != true)
            {

                label25.Text = Check();
                board_5x5[3, 0] = label25.Text;
                VanNyertes_5x5();

            }
        }

        private void label26_Click(object sender, EventArgs e)
        {
            if (label26.Text == "" && vanNyertes != true)
            {

                label26.Text = Check();
                board_5x5[3, 1] = label26.Text;
                VanNyertes_5x5();

            }
        }

        private void label27_Click(object sender, EventArgs e)
        {
            if (label27.Text == "" && vanNyertes != true)
            {

                label27.Text = Check();
                board_5x5[3, 2] = label27.Text;
                VanNyertes_5x5();

            }
        }

        private void label28_Click(object sender, EventArgs e)
        {
            if (label28.Text == "" && vanNyertes != true)
            {

                label28.Text = Check();
                board_5x5[3, 3] = label28.Text;
                VanNyertes_5x5();

            }
        }

        private void label29_Click(object sender, EventArgs e)
        {
            if (label29.Text == "" && vanNyertes != true)
            {

                label29.Text = Check();
                board_5x5[3,4] = label29.Text;
                VanNyertes_5x5();

            }
        }

        private void label30_Click(object sender, EventArgs e)
        {
            if (label30.Text == "" && vanNyertes != true)
            {

                label30.Text = Check();
                board_5x5[4, 0] = label30.Text;
                VanNyertes_5x5();

            }
        }

        private void label31_Click(object sender, EventArgs e)
        {
            if (label31.Text == "" && vanNyertes != true)
            {

                label31.Text = Check();
                board_5x5[4, 1] = label31.Text;
                VanNyertes_5x5();

            }
        }

        private void label32_Click(object sender, EventArgs e)
        {
            if (label32.Text == "" && vanNyertes != true)
            {

                label32.Text = Check();
                board_5x5[4,2] = label32.Text;
                VanNyertes_5x5();

            }
        }

        private void label33_Click(object sender, EventArgs e)
        {
            if (label33.Text == "" && vanNyertes != true)
            {

                label33.Text = Check();
                board_5x5[4, 3] = label33.Text;
                VanNyertes_5x5();

            }
        }

        private void label34_Click(object sender, EventArgs e)
        {
            if (label34.Text == "" && vanNyertes != true)
            {

                label34.Text = Check();
                board_5x5[4, 4] = label34.Text;
                VanNyertes_5x5();

            }
        }

        private void restartb2_Click(object sender, EventArgs e)
        {
            resetgame2();
        }

        private void menub2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            kezolap.Visible = true;
            EmbxEmb_5x5.Visible = false;
            resetgame2();
        }


        //                           EMBER x GÉP 3x3
        //---------------------------------------------------------------------------------

        private void label35_Click(object sender, EventArgs e)
        {
            
            if (label35.Text == "")
            {
                board_3x3[0, 0] = "O";
                label35.Text = "O";
                num++;
                VanNyertes_3x3();  



                if (!vanNyertes)
                {
                    Check_Gep_3x5();
                    VanNyertes_3x3();
                }  

            }

        }

        private void label36_Click(object sender, EventArgs e)
        {
            if (label36.Text == "")
            {
                board_3x3[0, 1] = "O";
                label36.Text = "O";
                num++;
                VanNyertes_3x3();



                if (!vanNyertes)
                {
                    Check_Gep_3x5();
                    VanNyertes_3x3();
                }

            }
        }

        private void label37_Click(object sender, EventArgs e)
        {
            if (label37.Text == "")
            {
                board_3x3[0, 2] = "O";
                label37.Text = "O";
                num++;
                VanNyertes_3x3();



                if (!vanNyertes)
                {
                    Check_Gep_3x5();
                    VanNyertes_3x3();
                }

            }
        }

        private void label38_Click(object sender, EventArgs e)
        {
            if (label38.Text == "")
            {
                board_3x3[1, 0] = "O";
                label38.Text = "O";
                num++;
                VanNyertes_3x3();



                if (!vanNyertes)
                {
                    Check_Gep_3x5();
                    VanNyertes_3x3();
                }

            }
        }

        private void label39_Click(object sender, EventArgs e)
        {
            if (label39.Text == "")
            {
                board_3x3[1, 1] = "O";
                label39.Text = "O";
                num++;
                VanNyertes_3x3();



                if (!vanNyertes)
                {
                    Check_Gep_3x5();
                    VanNyertes_3x3();
                }

            }
        }

        private void label40_Click(object sender, EventArgs e)
        {
            if (label40.Text == "")
            {
                board_3x3[1, 2] = "O";
                label40.Text = "O";
                num++;
                VanNyertes_3x3();



                if (!vanNyertes)
                {
                    Check_Gep_3x5();
                    VanNyertes_3x3();
                }

            }
        }

        private void label41_Click(object sender, EventArgs e)
        {
            if (label41.Text == "")
            {
                board_3x3[2, 0] = "O";
                label41.Text = "O";
                num++;
                VanNyertes_3x3();



                if (!vanNyertes)
                {
                    Check_Gep_3x5();
                    VanNyertes_3x3();
                }

            }
        }

        private void label42_Click(object sender, EventArgs e)
        {
            if (label42.Text == "")
            {
                board_3x3[2, 1] = "O";
                label42.Text = "O";
                num++;
                VanNyertes_3x3();



                if (!vanNyertes)
                {
                    Check_Gep_3x5();
                    VanNyertes_3x3();
                }

            }
        }

        private void label43_Click(object sender, EventArgs e)
        {
            if (label43.Text == "")
            {
                board_3x3[2, 2] = "O";
                label43.Text = "O";
                num++;
                VanNyertes_3x3();



                if (!vanNyertes)
                {
                    Check_Gep_3x5();
                    VanNyertes_3x3();
                }

            }
        }


        private void restartb3_Click(object sender, EventArgs e)
        {
            resetgame();
        }

        private void menub3_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            
            kezolap.Visible = true;
            EMbxGEP_3x3.Visible = false;
            resetgame();
        }


        //                     EMBER x GÉP 5x5
        //===============================================================================================
        private void label44_Click(object sender, EventArgs e)
        {
            if (label44.Text == "")
            {
                board_5x5[0, 0] = "O";
                label44.Text = "O";
                num++;
                VanNyertes_5x5();



                if (!vanNyertes)
                {
                    Check_Gep_3x5();
                    VanNyertes_5x5();
                }

            }
        }

        private void label45_Click(object sender, EventArgs e)
        {
            if (label45.Text == "")
            {
                board_5x5[0, 1] = "O";
                label45.Text = "O";
                num++;
                VanNyertes_5x5();



                if (!vanNyertes)
                {
                    Check_Gep_3x5();
                    VanNyertes_5x5();
                }

            }
        }

        private void label46_Click(object sender, EventArgs e)
        {
            if (label46.Text == "")
            {
                board_5x5[0, 2] = "O";
                label46.Text = "O";
                num++;
                VanNyertes_5x5();



                if (!vanNyertes)
                {
                    Check_Gep_3x5();
                    VanNyertes_5x5();
                }

            }
        }

        private void label47_Click(object sender, EventArgs e)
        {
            if (label47.Text == "")
            {
                board_5x5[0, 3] = "O";
                label47.Text = "O";
                num++;
                VanNyertes_5x5();



                if (!vanNyertes)
                {
                    Check_Gep_3x5();
                    VanNyertes_5x5();
                }

            }
        }

        private void label48_Click(object sender, EventArgs e)
        {
            if (label48.Text == "")
            {
                board_5x5[0, 4] = "O";
                label48.Text = "O";
                num++;
                VanNyertes_5x5();



                if (!vanNyertes)
                {
                    Check_Gep_3x5();
                    VanNyertes_5x5();
                }

            }
        }

        private void label49_Click(object sender, EventArgs e)
        {
            if (label49.Text == "")
            {
                board_5x5[1, 0] = "O";
                label49.Text = "O";
                num++;
                VanNyertes_5x5();



                if (!vanNyertes)
                {
                    Check_Gep_3x5();
                    VanNyertes_5x5();
                }

            }
        }

        private void label50_Click(object sender, EventArgs e)
        {
            if (label50.Text == "")
            {
                board_5x5[1, 1] = "O";
                label50.Text = "O";
                num++;
                VanNyertes_5x5();



                if (!vanNyertes)
                {
                    Check_Gep_3x5();
                    VanNyertes_5x5();
                }

            }
        }

        private void label51_Click(object sender, EventArgs e)
        {
            if (label51.Text == "")
            {
                board_5x5[1, 2] = "O";
                label51.Text = "O";
                num++;
                VanNyertes_5x5();



                if (!vanNyertes)
                {
                    Check_Gep_3x5();
                    VanNyertes_5x5();
                }

            }
        }

        private void label52_Click(object sender, EventArgs e)
        {
            if (label52.Text == "")
            {
                board_5x5[1, 3] = "O";
                label52.Text = "O";
                num++;
                VanNyertes_5x5();



                if (!vanNyertes)
                {
                    Check_Gep_3x5();
                    VanNyertes_5x5();
                }

            }
        }

        private void label53_Click(object sender, EventArgs e)
        {
            if (label53.Text == "")
            {
                board_5x5[1, 4] = "O";
                label53.Text = "O";
                num++;
                VanNyertes_5x5();



                if (!vanNyertes)
                {
                    Check_Gep_3x5();
                    VanNyertes_5x5();
                }

            }
        }

        private void label54_Click(object sender, EventArgs e)
        {
            if (label54.Text == "")
            {
                board_5x5[2, 0] = "O";
                label54.Text = "O";
                num++;
                VanNyertes_5x5();



                if (!vanNyertes)
                {
                    Check_Gep_3x5();
                    VanNyertes_5x5();
                }

            }
        }

        private void label55_Click(object sender, EventArgs e)
        {
            if (label55.Text == "")
            {
                board_5x5[2, 1] = "O";
                label55.Text = "O";
                num++;
                VanNyertes_5x5();



                if (!vanNyertes)
                {
                    Check_Gep_3x5();
                    VanNyertes_5x5();
                }

            }
        }

        private void label56_Click(object sender, EventArgs e)
        {
            if (label56.Text == "")
            {
                board_5x5[2, 2] = "O";
                label56.Text = "O";
                num++;
                VanNyertes_5x5();



                if (!vanNyertes)
                {
                    Check_Gep_3x5();
                    VanNyertes_5x5();
                }

            }
        }

        private void label57_Click(object sender, EventArgs e)
        {
            if (label57.Text == "")
            {
                board_5x5[2, 3] = "O";
                label57.Text = "O";
                num++;
                VanNyertes_5x5();



                if (!vanNyertes)
                {
                    Check_Gep_3x5();
                    VanNyertes_5x5();
                }

            }
        }

        private void label58_Click(object sender, EventArgs e)
        {
            if (label58.Text == "")
            {
                board_5x5[2, 4] = "O";
                label58.Text = "O";
                num++;
                VanNyertes_5x5();



                if (!vanNyertes)
                {
                    Check_Gep_3x5();
                    VanNyertes_5x5();
                }

            }
        }

        private void label59_Click(object sender, EventArgs e)
        {
            if (label59.Text == "")
            {
                board_5x5[3, 0] = "O";
                label59.Text = "O";
                num++;
                VanNyertes_5x5();



                if (!vanNyertes)
                {
                    Check_Gep_3x5();
                    VanNyertes_5x5();
                }

            }
        }

        private void label60_Click(object sender, EventArgs e)
        {
            if (label60.Text == "")
            {
                board_5x5[3,1] = "O";
                label60.Text = "O";
                num++;
                VanNyertes_5x5();



                if (!vanNyertes)
                {
                    Check_Gep_3x5();
                    VanNyertes_5x5();
                }

            }
        }

        private void label61_Click(object sender, EventArgs e)
        {
            if (label61.Text == "")
            {
                board_5x5[3, 2] = "O";
                label61.Text = "O";
                num++;
                VanNyertes_5x5();



                if (!vanNyertes)
                {
                    Check_Gep_3x5();
                    VanNyertes_5x5();
                }

            }
        }

        private void label62_Click(object sender, EventArgs e)
        {
            if (label62.Text == "")
            {
                board_5x5[3, 3] = "O";
                label62.Text = "O";
                num++;
                VanNyertes_5x5();



                if (!vanNyertes)
                {
                    Check_Gep_3x5();
                    VanNyertes_5x5();
                }

            }
        }

        private void label63_Click(object sender, EventArgs e)
        {
            if (label63.Text == "")
            {
                board_5x5[3, 4] = "O";
                label63.Text = "O";
                num++;
                VanNyertes_5x5();



                if (!vanNyertes)
                {
                    Check_Gep_3x5();
                    VanNyertes_5x5();
                }

            }
        }

        private void label64_Click(object sender, EventArgs e)
        {
            if (label64.Text == "")
            {
                board_5x5[4, 0] = "O";
                label64.Text = "O";
                num++;
                VanNyertes_5x5();



                if (!vanNyertes)
                {
                    Check_Gep_3x5();
                    VanNyertes_5x5();
                }

            }
        }

        private void label65_Click(object sender, EventArgs e)
        {
            if (label65.Text == "")
            {
                board_5x5[4, 1] = "O";
                label65.Text = "O";
                num++;
                VanNyertes_5x5();



                if (!vanNyertes)
                {
                    Check_Gep_3x5();
                    VanNyertes_5x5();
                }

            }
        }

        private void label66_Click(object sender, EventArgs e)
        {
            if (label66.Text == "")
            {
                board_5x5[4, 2] = "O";
                label66.Text = "O";
                num++;
                VanNyertes_5x5();



                if (!vanNyertes)
                {
                    Check_Gep_3x5();
                    VanNyertes_5x5();
                }

            }
        }

        private void label67_Click(object sender, EventArgs e)
        {
            if (label67.Text == "")
            {
                board_5x5[4, 3] = "O";
                label67.Text = "O";
                num++;
                VanNyertes_5x5();



                if (!vanNyertes)
                {
                    Check_Gep_3x5();
                    VanNyertes_5x5();
                }

            }
        }

        private void label68_Click(object sender, EventArgs e)
        {
            if (label68.Text == "")
            {
                board_5x5[4, 4] = "O";
                label68.Text = "O";
                num++;
                VanNyertes_5x5();



                if (!vanNyertes)
                {
                    Check_Gep_3x5();
                    VanNyertes_5x5();
                }

            }
        }

        private void restartb4_Click(object sender, EventArgs e)
        {
            resetgame2();
        }

        private void menub4_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";

            kezolap.Visible = true;
            groupBox3.Visible = false;
            resetgame2();


        }
    }
}
