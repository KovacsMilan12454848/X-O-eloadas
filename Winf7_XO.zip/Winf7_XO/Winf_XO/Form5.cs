﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Winf_XO
{
    public partial class Form5 : Form
    {
        public System.Windows.Forms.Label[,] labels;
        
        public Form5()
        {
            InitializeComponent();
            


            labels = new System.Windows.Forms.Label[,]
            {
                    { label1, label2, label3, label4, label5 },
                    { label6, label7, label8, label9, label10 },
                    { label11, label12, label13, label14, label15 },
                    { label16, label17, label18, label19, label20 },
                    { label21, label22, label23, label24, label25 }
            };
        }
        string[,] board = { { "1", "2", "3","4", "5" },
                            { "6", "7", "8","9", "10" },
                            { "11", "12", "13","14", "15" },
                            { "16", "17", "18","19", "20" },
                            { "21", "22", "23","24", "25" }
                          };

        
        public string P1 { get; set; }

        Random rnd = new Random();
        int num = 0;
        bool vanNyertes = false;





        
        
        public void Check()
        {

            
            int retries = 0;


            while (retries < 25)
            {



                int tomb1 = rnd.Next(5);
                int tomb2 = rnd.Next(5);
                if (board[tomb1, tomb2] != "X" && board[tomb1, tomb2] != "O")
                {
                    num++;

                    board[tomb1, tomb2] = "X";
                    labels[tomb1, tomb2].Text = "X";
                    break;
                }

                retries++;
            }


        }
        public void resetgame()
        {

            foreach (System.Windows.Forms.Label i in labels)
            {
                i.Text = "";
            }
            num = 0;
            vanNyertes = false;



            board = new string[,]{
                            { "1", "2", "3","4", "5" },
                            { "6", "7", "8","9", "10" },
                            { "11", "12", "13","14", "15" },
                            { "16", "17", "18","19", "20" },
                            { "21", "22", "23","24", "25" }
            };
            restartb.Visible = false;
            menub.Visible = false;
            gyozteslab.Visible = false;


        }

        public void menu()
        {
            gyozteslab.Visible = true;
            restartb.Visible = true;
            menub.Visible = true;

        }

        public void VanNyertes()
        {


            if (num > 5)
            {


                // ---
                for (int i = 0; i < 5; i++)
                {
                    if (board[i, 0] == board[i, 1] && board[i, 1] == board[i, 2] && board[i, 2] == board[i, 3] && board[i, 3] == board[i, 4])
                    {
                        gyozteslab.Text = $"A Győztes: {board[i, 0]}";
                        menu();
                        vanNyertes = true;

                    }

                }
                // |
                for (int i = 0; i < 5; i++)
                {
                    if (board[0, i] == board[1, i] && board[1, i] == board[2, i] && board[2, i] == board[3, i] && board[3, i] == board[4, i])
                    {
                        gyozteslab.Text = $"A Győztes: {board[0, i]}";
                        menu();
                        vanNyertes = true;

                    }

                }
                // \, /
                if (board[0, 0] == board[1, 1] && board[1, 1] == board[2, 2] && board[2, 2] == board[3, 3] && board[3, 3] == board[4, 4])
                {
                    gyozteslab.Text = $"A Győztes: {board[0, 0]}";
                    menu();
                    vanNyertes = true;
                }

                if (board[0, 4] == board[1, 3] && board[1, 3] == board[2, 2] && board[2, 2] == board[3, 1] && board[3, 1] == board[4, 0])
                {
                    gyozteslab.Text = $"A Győztes: {board[0, 4]}";
                    menu();
                    vanNyertes = true;
                }


                if (num == 25 && vanNyertes == false)
                {
                    gyozteslab.Text = $"Döntetlen";
                    menu();

                }

            }

        }



        private void Form5_Load(object sender, EventArgs e)
        {

            label100.Text = P1;

        }



        private void label1_Click(object sender, EventArgs e)
        {


            if (label1.Text == "")
            {

                board[0, 0] = "O";
                label1.Text = "O";
                num++;


                Check();
                VanNyertes();
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

            if (label2.Text == "")
            {

                board[0, 1] = "O";
                label2.Text = "O";
                num++;

                Check();
                VanNyertes();
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

            if (label3.Text == "")
            {

                board[0, 2] = "O";
                label3.Text = "O";
                num++;

                Check();
                VanNyertes();
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

            if (label4.Text == "")
            {
                board[0, 3] = "O";
                label4.Text = "O";
                num++;

                Check();
                VanNyertes();
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

            if (label5.Text == "")
            {
                board[0, 4] = "O";
                label5.Text = "O";
                num++;

                Check();
                VanNyertes();
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

            if (label6.Text == "")
            {
                board[1, 0] = "O";
                label6.Text = "O";
                num++;

                Check();
                VanNyertes();
            }
        }

        private void label7_Click(object sender, EventArgs e)
        {

            if (label7.Text == "")
            {
                board[1, 1] = "O";
                label7.Text = "O";
                num++;

                Check();
                VanNyertes();
            }
        }

        private void label8_Click(object sender, EventArgs e)
        {

            if (label8.Text == "")
            {
                board[1, 2] = "O";
                label8.Text = "O";
                num++;

                Check();
                VanNyertes();
            }
        }

        private void label9_Click(object sender, EventArgs e)
        {

            if (label9.Text == "")
            {
                board[1, 3] = "O";
                label9.Text = "O";
                num++;

                Check();
                VanNyertes();
            }
        }

        private void label10_Click(object sender, EventArgs e)
        {

            if (label10.Text == "")
            {
                board[1, 4] = "O";
                label10.Text = "O";
                num++;

                Check();
                VanNyertes();
            }
        }

        private void label11_Click(object sender, EventArgs e)
        {

            if (label11.Text == "")
            {
                board[2, 0] = "O";
                label11.Text = "O";
                num++;

                Check();
                VanNyertes();
            }
        }

        private void label12_Click(object sender, EventArgs e)
        {

            if (label12.Text == "")
            {
                board[2, 1] = "O";
                label12.Text = "O";
                num++;

                Check();
                VanNyertes();
            }
        }

        private void label13_Click(object sender, EventArgs e)
        {

            if (label13.Text == "")
            {
                board[2, 2] = "O";
                label13.Text = "O";
                num++;

                Check();
                VanNyertes();
            }
        }

        private void label14_Click(object sender, EventArgs e)
        {

            if (label14.Text == "")
            {
                board[2, 3] = "O";
                label14.Text = "O";
                num++;

                Check();
                VanNyertes();
            }
        }

        private void label15_Click(object sender, EventArgs e)
        {

            if (label15.Text == "")
            {
                board[2, 4] = "O";
                label15.Text = "O";
                num++;

                Check();
                VanNyertes();
            }
        }

        private void label16_Click(object sender, EventArgs e)
        {

            if (label16.Text == "")
            {
                board[3, 0] = "O";
                label16.Text = "O";
                num++;

                Check();
                VanNyertes();
            }
        }

        private void label17_Click(object sender, EventArgs e)
        {

            if (label17.Text == "")
            {
                board[3, 1] = "O";
                label17.Text = "O";
                num++;

                Check();
                VanNyertes();
            }
        }

        private void label18_Click(object sender, EventArgs e)
        {

            if (label18.Text == "")
            {
                board[3, 2] = "O";
                label18.Text = "O";
                num++;

                Check();
                VanNyertes();
            }
        }

        private void label19_Click(object sender, EventArgs e)
        {

            if (label19.Text == "")
            {
                board[3, 3] = "O";
                label19.Text = "O";
                num++;

                Check();
                VanNyertes();
            }
        }

        private void label20_Click(object sender, EventArgs e)
        {

            if (label20.Text == "")
            {
                board[3, 4] = "O";
                label20.Text = "O";

                num++;

                Check();
                VanNyertes();
            }
        }

        private void label21_Click(object sender, EventArgs e)
        {

            if (label21.Text == "")
            {
                board[4, 0] = "O";
                label21.Text = "O";
                num++;

                Check();
                VanNyertes();
            }
        }

        private void label22_Click(object sender, EventArgs e)
        {

            if (label22.Text == "")
            {
                board[4, 1] = "O";
                label22.Text = "O";
                num++;

                Check();
                VanNyertes();
            }
        }

        private void label23_Click(object sender, EventArgs e)
        {

            if (label23.Text == "")
            {
                board[4, 2] = "O";
                label23.Text = "O";
                num++;

                Check();
                VanNyertes();
            }
        }

        private void label24_Click(object sender, EventArgs e)
        {

            if (label24.Text == "")
            {
                board[4, 3] = "O";
                label24.Text = "O";
                num++;

                Check();
                VanNyertes();
            }
        }

        private void label25_Click(object sender, EventArgs e)
        {

            if (label25.Text == "")
            {
                board[4, 4] = "O";
                label25.Text = "O";
                num++;

                Check();
                VanNyertes();
            }
        }


        private void restartb_Click(object sender, EventArgs e)
        {
            resetgame();
        }

        private void menub_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            
            this.Hide(); // Form1 elrejtése a bezárás helyett
            form.Show(); // Form2 megnyitása

            form.FormClosed += (s, args) => this.Close();
        }
    }
}
