﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Winf_XO
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        string[,] board = { { "1", "2", "3","4", "5" },
                            { "6", "7", "8","9", "10" },
                            { "11", "12", "13","14", "15" },
                            { "16", "17", "18","19", "20" },
                            { "21", "22", "23","24", "25" } 
                          };

        private System.Windows.Forms.Label[] labels = new System.Windows.Forms.Label[25];
        public string P1 { get; set; }
        public string P2 { get; set; }

        private void Form3_Load(object sender, EventArgs e)
        {
            label100.Text = P1;
            label200.Text = P2;

            labels = new System.Windows.Forms.Label[25]
            {
                label1, label2, label3, label4, label5 ,
                label6, label7, label8, label9, label10 ,
                label11, label12, label13, label14, label15 ,
                label16, label17, label18, label19, label20 ,
                label21, label22, label23, label24, label25 
            };
        }


        public void resetgame()
        {

            foreach (System.Windows.Forms.Label i in labels)
            {
                i.Text = "";
            }
            num = 0;
            vanNyertes = false;

           

            board = new string[,]{
                            { "1", "2", "3","4", "5" },
                            { "6", "7", "8","9", "10" },
                            { "11", "12", "13","14", "15" },
                            { "16", "17", "18","19", "20" },
                            { "21", "22", "23","24", "25" }
            };
            restartb.Visible = false;
            menub.Visible = false;
            gyozteslab.Visible = false;


        }

        int num = 0;
        bool vanNyertes = false;
        public string Check()
        {


            if (num % 2 == 0)
            {
                num++;

                return "X";
            }
            else
            {
                num++;

                return "O";
            }
            // megnez van e nyertes     
        }


        public void menu()
        {
            gyozteslab.Visible = true;
            restartb.Visible = true;
            menub.Visible = true;

        }

        public void VanNyertes()
        {


            if (num > 5)
            {


                // ---
                for (int i = 0; i <5 ; i++)
                {
                    if (board[i, 0] == board[i, 1] && board[i, 1] == board[i, 2] && board[i, 2] == board[i, 3] && board[i, 3] == board[i, 4])
                    {
                        gyozteslab.Text = $"A Győztes: {board[i, 0]}";
                        menu();
                        vanNyertes = true;

                    }

                }
                // |
                for (int i = 0; i < 5; i++)
                {
                    if (board[0, i] == board[1, i] && board[1, i] == board[2, i] && board[2, i] == board[3, i] && board[3, i] == board[4, i])
                    {
                        gyozteslab.Text = $"A Győztes: {board[0, i]}";
                        menu();
                        vanNyertes = true;
                        
                    }

                }
                // \, /
                if (board[0, 0] == board[1, 1] && board[1, 1] == board[2, 2] && board[2, 2] == board[3, 3] && board[3, 3] == board[4, 4])
                {
                    gyozteslab.Text = $"A Győztes: {board[0, 0]}";
                    menu();
                    vanNyertes = true;
                }

                if (board[0, 4] == board[1, 3] && board[1, 3] == board[2, 2] && board[2, 2] == board[3, 1] && board[3, 1] == board[4, 0])
                {
                    gyozteslab.Text = $"A Győztes: {board[0, 4]}";
                    menu();
                    vanNyertes = true;
                }


                if (num == 25 && vanNyertes == false)
                {
                    label1.Text = $"Döntetlen";
                    menu();
                   
                }

            }

        }

        private void label3_Click(object sender, EventArgs e)
        {
            if (label1.Text == ""  && vanNyertes != true)
            {
                label1.Text = Check();

                board[0, 0] = label1.Text;
                VanNyertes();

            }

        }

        private void label4_Click(object sender, EventArgs e)
        {
            if (label2.Text == "" && vanNyertes != true)
            {
                label2.Text = Check();

                board[0, 1] = label2.Text;
                VanNyertes();

            }
        }

        private void label5_Click(object sender, EventArgs e)
        {
            if (label5.Text == "" && vanNyertes != true)
            {
                label5.Text = Check();

                board[0, 2] = label5.Text;
                VanNyertes();

            }
        }

        private void label6_Click(object sender, EventArgs e)
        {
            if (label3.Text == "" && vanNyertes != true)
            {
                label3.Text = Check();

                board[0, 3] = label3.Text;
                VanNyertes();

            }
        }

        private void label7_Click(object sender, EventArgs e)
        {
            if (label4.Text == "" && vanNyertes != true)
            {
                label4.Text = Check();

                board[0, 4] = label4.Text;
                VanNyertes();

            }
        }

        private void label8_Click(object sender, EventArgs e)
        {
            if (label6.Text == "" && vanNyertes != true)
            {
                label6.Text = Check();

                board[1, 0] = label6.Text;
                VanNyertes();

            }
        }

        private void label9_Click(object sender, EventArgs e)
        {
            if (label7.Text == "" && vanNyertes != true)
            {
                label7.Text = Check();

                board[1, 1] = label7.Text;
                VanNyertes();

            }
        }

        private void label12_Click(object sender, EventArgs e)
        {
            if (label8.Text == "" && vanNyertes != true)
            {
                label8.Text = Check();

                board[1, 2] = label8.Text;
                VanNyertes();

            }
        }

        private void label13_Click(object sender, EventArgs e)
        {
            if (label9.Text == "" && vanNyertes != true)
            {
                label9.Text = Check();

                board[1, 3] = label9.Text;
                VanNyertes();

            }
        }

        private void label14_Click(object sender, EventArgs e)
        {
            if (label10.Text == "" && vanNyertes != true)
            {
                label10.Text = Check();

                board[1, 4] = label10.Text;
                VanNyertes();

            }
        }

        private void label15_Click(object sender, EventArgs e)
        {
            if (label11.Text == "" && vanNyertes != true)
            {
                label11.Text = Check();

                board[2, 0] = label11.Text;
                VanNyertes();

            }
        }

        private void label16_Click(object sender, EventArgs e)
        {
            if (label12.Text == "" && vanNyertes != true)
            {
                label12.Text = Check();

                board[2, 1] = label12.Text;
                VanNyertes();

            }
        }

        private void label17_Click(object sender, EventArgs e)
        {
            if (label13.Text == "" && vanNyertes != true)
            {
                label13.Text = Check();

                board[2, 2] = label13.Text;
                VanNyertes();

            }

        }

        private void label18_Click(object sender, EventArgs e)
        {
            if (label14.Text == "" && vanNyertes != true)
            {
                label14.Text = Check();

                board[2, 3] = label14.Text;
                VanNyertes();

            }
        }

        private void label19_Click(object sender, EventArgs e)
        {
            if (label15.Text == "" && vanNyertes != true)
            {
                label15.Text = Check();

                board[2, 4] = label15.Text;
                VanNyertes();

            }

        }

        private void label20_Click(object sender, EventArgs e)
        {
            if (label16.Text == "" && vanNyertes != true)
            {
                label16.Text = Check();

                board[3, 0] = label16.Text;
                VanNyertes();

            }
        }

        private void label21_Click(object sender, EventArgs e)
        {
            if (label17.Text == "" && vanNyertes != true)
            {
                label17.Text = Check();

                board[3, 1] = label17.Text;
                VanNyertes();

            }
        }

        private void label22_Click(object sender, EventArgs e)
        {
            if (label18.Text == "" && vanNyertes != true)
            {
                label18.Text = Check();

                board[3, 2] = label18.Text;
                VanNyertes();

            }

        }

        private void label23_Click(object sender, EventArgs e)
        {
            if (label19.Text == "" && vanNyertes != true)
            {
                label19.Text = Check();

                board[3, 3] = label19.Text;
                VanNyertes();

            }
        }

        private void label24_Click(object sender, EventArgs e)
        {
            if (label20.Text == "" && vanNyertes != true)
            {
                label20.Text = Check();

                board[3, 4] = label20.Text;
                VanNyertes();

            }

        }

        private void label25_Click(object sender, EventArgs e)
        {
            if (label21.Text == "" && vanNyertes != true)
            {
                label21.Text = Check();

                board[4, 0] = label21.Text;
                VanNyertes();

            }
        }

        private void label26_Click(object sender, EventArgs e)
        {
            if (label22.Text == "" && vanNyertes != true)
            {
                label22.Text = Check();

                board[4, 1] = label22.Text;
                VanNyertes();

            }
        }

        private void label27_Click(object sender, EventArgs e)
        {
            if (label23.Text == "" && vanNyertes != true)
            {
                label23.Text = Check();

                board[4, 2] = label23.Text;
                VanNyertes();

            }
        }

        private void label28_Click(object sender, EventArgs e)
        {
            if (label24.Text == "" && vanNyertes != true)
            {
                label24.Text = Check();

                board[4, 3] = label24.Text;
                VanNyertes();

            }
        }

        private void label29_Click(object sender, EventArgs e)
        {
            if (label25.Text == "" && vanNyertes != true)
            {
                label25.Text = Check();

                board[4, 4] = label25.Text;
                VanNyertes();

            }

        }


        private void restartb_Click(object sender, EventArgs e)
        {
            resetgame();
        }
        private void menub_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();

            this.Hide(); // Form1 elrejtése a bezárás helyett
            form.Show(); // Form2 megnyitása

            form.FormClosed += (s, args) => this.Close();
        }







        private void Label11_Click(object sender, EventArgs e)
        {

        }

        private void ProgressBar8_Click(object sender, EventArgs e)
        {

        }

        private void ProgressBar7_Click(object sender, EventArgs e)
        {

        }

        private void ProgressBar6_Click(object sender, EventArgs e)
        {

        }

        private void ProgressBar5_Click(object sender, EventArgs e)
        {

        }

        private void ProgressBar4_Click(object sender, EventArgs e)
        {

        }

        private void ProgressBar3_Click(object sender, EventArgs e)
        {

        }

        private void ProgressBar2_Click(object sender, EventArgs e)
        {

        }

        private void ProgressBar1_Click(object sender, EventArgs e)
        {

        }

        private void Label10_Click(object sender, EventArgs e)
        {

        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        
    }
}
