﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Winf_XO
{
    public partial class Form4 : Form
    {
        public System.Windows.Forms.Label[,] labels;
        public Form4()
        {
            InitializeComponent();
            labels = new System.Windows.Forms.Label[,]
            {
                { label26, label2, label3 },
                { label4, label5, label6 },
                { label7, label8, label9 }
            };
        }


        Random rnd = new Random();
        string[,] board = { { "1", "2", "3" }, { "4", "5", "6" }, { "7", "8", "9" } };

        
            
        
        public string P1 { get; set; }
       
        int num = 0;
        bool vanNyertes = false;


        public void Check()
        {
           

           int retries = 0;

            while (retries<10) 
            {
                int ind = rnd.Next(3);
                int ind2 = rnd.Next(3);

                if (board[ind, ind2] != "X" && board[ind, ind2] != "O")
                {
                    board[ind, ind2] = "X";
                    labels[ind, ind2].Text = "X";

                    
                    num++;

                    break;
                }

                retries++;
            }

            
        }







        public void resetgame()
        {

            foreach (System.Windows.Forms.Label i in labels)
            {
                i.Text = "";
            }
            num = 0;
            vanNyertes = false;

            board = new string[,]
            {
                { "1", "2", "3" },
                { "4", "5", "6" },
                { "7", "8", "9" }
            };
            restartb.Visible = false;
            menub.Visible = false;
            gyozteslab.Visible = false;


        }






        public void menu()
        {
            gyozteslab.Visible = true;
            restartb.Visible = true;
            menub.Visible = true;

        }

        public void VanNyertes()
        {

            
            if (num > 3)
            {


                // ---
                for (int i = 0; i <= 2; i++)
                {
                    if (board[i, 0] == board[i, 1] && board[i, 1] == board[i, 2])
                    {
                        gyozteslab.Text = $"A Győztes: {board[i, 0]}";
                        menu();
                        vanNyertes = true;

                    }

                }
                // |
                for (int i = 0; i <= 2; i++)
                {
                    if (board[0, i] == board[1, i] && board[2, i] == board[1, i])
                    {
                        gyozteslab.Text = $"A Győztes: {board[0, i]}";
                        menu();
                        vanNyertes = true;

                    }

                }
                // \, /
                if (board[0, 0] == board[1, 1] && board[2, 2] == board[1, 1])
                {

                    gyozteslab.Text = $"A Győztes: {board[0, 0]}";
                    menu();
                    vanNyertes = true;
                }

                if (board[0, 2] == board[1, 1] && board[2, 0] == board[1, 1])
                {
                    gyozteslab.Text = $"A Győztes: {board[0, 2]}";
                    menu();
                    vanNyertes = true;

                }
                if (num == 9 && !vanNyertes)
                {
                    gyozteslab.Text = $"Döntetlen";  // Display "Döntetlen" for a tie
                    menu();
                }




            }

        }

        private void Form4_Load(object sender, EventArgs e)
        {
            label13.Text = P1;
        }

        private void label26_Click(object sender, EventArgs e)
        {
            if (label26.Text == "")
            {
                board[0, 0] = "O";
                label26.Text = "O";
                num++;  // Increment for the player's move
                VanNyertes();


                // Check
                Check();  // Computer makes its move
                VanNyertes();
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {
            if (label2.Text == "")
            {
                board[0, 1] = "O";
                label2.Text = "O";
                num++;  // Increment for the player's move
                VanNyertes();


                // Check
                Check();  // Computer makes its move
                VanNyertes();
            }

        }

        private void label3_Click(object sender, EventArgs e)
        {
            if (label3.Text == "")
            {
                board[0, 2] = "O";
                label3.Text = "O";
                num++;  // Increment for the player's move
                VanNyertes();


                // Check
                Check();  // Computer makes its move
                VanNyertes();
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {
            if (label4.Text == "")
            {
                board[1, 0] = "O";
                label4.Text = "O";
                num++;  // Increment for the player's move
                VanNyertes();

                Check();  // Computer makes its move
                VanNyertes();
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {
            if (label5.Text == "")
            {
                board[1, 1] = "O";
                label5.Text = "O";
                num++;  // Increment for the player's move
                VanNyertes();



                Check();  // Computer makes its move
                VanNyertes();
            }


        }

        private void label6_Click(object sender, EventArgs e)
        {
            if (label6.Text == "")
            {
                board[1, 2] = "O";
                label6.Text = "O";
                num++;  // Increment for the player's move
                VanNyertes();


                // Check
                Check();  // Computer makes its move
                VanNyertes();
            }
        }

        private void label7_Click(object sender, EventArgs e)
        {
            if (label7.Text == "")
            {
                board[2, 0] = "O";
                label7.Text = "O";
                num++;

                Check();
                VanNyertes();
            }


        }

        private void label8_Click(object sender, EventArgs e)
        {
            if (label8.Text == "")
            {
                board[2, 1] = "O";
                label8.Text = "O";
                num++;

                Check();
                VanNyertes();
            }
        }

        private void label9_Click(object sender, EventArgs e)
        {
            if (label9.Text == "")
            {
                board[2, 2] = "O";
                label9.Text = "O";
                num++;

                Check();
                VanNyertes();
            }
        }

        private void restartb_Click(object sender, EventArgs e)
        {
            
        }

        private void menub_Click(object sender, EventArgs e)
        {

        }

        private void restartb_Click_1(object sender, EventArgs e)
        {
            resetgame();
        }

        private void menub_Click_1(object sender, EventArgs e)
        {
            Form1 form = new Form1();

            this.Hide(); // Form1 elrejtése a bezárás helyett
            form.Show(); // Form2 megnyitása

            form.FormClosed += (s, args) => this.Close();
        }
    }
}
