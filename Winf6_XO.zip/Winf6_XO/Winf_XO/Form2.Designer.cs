﻿namespace Winf_XO
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.szoveg = new System.Windows.Forms.Label();
            this.progressBar2 = new System.Windows.Forms.ProgressBar();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.progressBar3 = new System.Windows.Forms.ProgressBar();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.progressBar4 = new System.Windows.Forms.ProgressBar();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.threegb = new System.Windows.Forms.GroupBox();
            this.gyozteslab = new System.Windows.Forms.Label();
            this.menub = new System.Windows.Forms.Button();
            this.restartb = new System.Windows.Forms.Button();
            this.threegb.SuspendLayout();
            this.SuspendLayout();
            // 
            // szoveg
            // 
            this.szoveg.AutoSize = true;
            this.szoveg.BackColor = System.Drawing.Color.Red;
            this.szoveg.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.szoveg.Location = new System.Drawing.Point(223, -79);
            this.szoveg.Name = "szoveg";
            this.szoveg.Size = new System.Drawing.Size(231, 32);
            this.szoveg.TabIndex = 29;
            this.szoveg.Text = "Mindig az X-kezd";
            // 
            // progressBar2
            // 
            this.progressBar2.BackColor = System.Drawing.Color.Red;
            this.progressBar2.Location = new System.Drawing.Point(187, 279);
            this.progressBar2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar2.Name = "progressBar2";
            this.progressBar2.Size = new System.Drawing.Size(700, 25);
            this.progressBar2.TabIndex = 17;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei UI", 64.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.Control;
            this.label2.Location = new System.Drawing.Point(460, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(168, 158);
            this.label2.TabIndex = 20;
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei UI", 64.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.Control;
            this.label3.Location = new System.Drawing.Point(719, 75);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(168, 158);
            this.label3.TabIndex = 21;
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label3.Click += new System.EventHandler(this.label3_Click_1);
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label5.Font = new System.Drawing.Font("Microsoft YaHei UI", 64.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.Control;
            this.label5.Location = new System.Drawing.Point(460, 326);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(168, 158);
            this.label5.TabIndex = 22;
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label6.Font = new System.Drawing.Font("Microsoft YaHei UI", 64.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.Control;
            this.label6.Location = new System.Drawing.Point(719, 326);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(168, 158);
            this.label6.TabIndex = 23;
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label7.Font = new System.Drawing.Font("Microsoft YaHei UI", 64.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.Control;
            this.label7.Location = new System.Drawing.Point(184, 583);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(168, 158);
            this.label7.TabIndex = 24;
            this.label7.Tag = "";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label8.Font = new System.Drawing.Font("Microsoft YaHei UI", 64.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.Control;
            this.label8.Location = new System.Drawing.Point(460, 583);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(168, 158);
            this.label8.TabIndex = 25;
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label9
            // 
            this.label9.AccessibleRole = System.Windows.Forms.AccessibleRole.Link;
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label9.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label9.Font = new System.Drawing.Font("Microsoft YaHei UI", 64.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.Control;
            this.label9.Location = new System.Drawing.Point(719, 583);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(168, 158);
            this.label9.TabIndex = 26;
            this.label9.Tag = "";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei UI", 64.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.Control;
            this.label4.Location = new System.Drawing.Point(184, 326);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(168, 158);
            this.label4.TabIndex = 27;
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label26
            // 
            this.label26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label26.Font = new System.Drawing.Font("Microsoft YaHei UI", 64.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.SystemColors.Control;
            this.label26.Location = new System.Drawing.Point(184, 75);
            this.label26.Margin = new System.Windows.Forms.Padding(0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(168, 158);
            this.label26.TabIndex = 28;
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label26.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // progressBar3
            // 
            this.progressBar3.BackColor = System.Drawing.Color.Red;
            this.progressBar3.Location = new System.Drawing.Point(663, 57);
            this.progressBar3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar3.Name = "progressBar3";
            this.progressBar3.Size = new System.Drawing.Size(25, 700);
            this.progressBar3.TabIndex = 30;
            // 
            // progressBar1
            // 
            this.progressBar1.BackColor = System.Drawing.Color.Red;
            this.progressBar1.Location = new System.Drawing.Point(388, 57);
            this.progressBar1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(25, 700);
            this.progressBar1.TabIndex = 31;
            // 
            // progressBar4
            // 
            this.progressBar4.BackColor = System.Drawing.Color.Red;
            this.progressBar4.Location = new System.Drawing.Point(177, 533);
            this.progressBar4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar4.Name = "progressBar4";
            this.progressBar4.Size = new System.Drawing.Size(700, 25);
            this.progressBar4.TabIndex = 32;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft YaHei", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label10.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label10.Location = new System.Drawing.Point(33, 30);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(48, 43);
            this.label10.TabIndex = 33;
            this.label10.Text = "X:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft YaHei", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label11.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label11.Location = new System.Drawing.Point(33, 75);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(54, 43);
            this.label11.TabIndex = 34;
            this.label11.Text = "O:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft YaHei", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label12.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label12.Location = new System.Drawing.Point(95, 82);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(0, 30);
            this.label12.TabIndex = 35;
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label13.Font = new System.Drawing.Font("Microsoft YaHei", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label13.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label13.Location = new System.Drawing.Point(95, 36);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(0, 30);
            this.label13.TabIndex = 36;
            // 
            // threegb
            // 
            this.threegb.Controls.Add(this.gyozteslab);
            this.threegb.Controls.Add(this.menub);
            this.threegb.Controls.Add(this.restartb);
            this.threegb.Controls.Add(this.label13);
            this.threegb.Controls.Add(this.label12);
            this.threegb.Controls.Add(this.label11);
            this.threegb.Controls.Add(this.label10);
            this.threegb.Controls.Add(this.progressBar4);
            this.threegb.Controls.Add(this.progressBar1);
            this.threegb.Controls.Add(this.progressBar3);
            this.threegb.Controls.Add(this.label26);
            this.threegb.Controls.Add(this.label4);
            this.threegb.Controls.Add(this.label9);
            this.threegb.Controls.Add(this.label8);
            this.threegb.Controls.Add(this.label7);
            this.threegb.Controls.Add(this.label6);
            this.threegb.Controls.Add(this.label5);
            this.threegb.Controls.Add(this.label3);
            this.threegb.Controls.Add(this.label2);
            this.threegb.Controls.Add(this.progressBar2);
            this.threegb.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.threegb.Location = new System.Drawing.Point(-13, -12);
            this.threegb.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.threegb.Name = "threegb";
            this.threegb.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.threegb.Size = new System.Drawing.Size(1111, 871);
            this.threegb.TabIndex = 37;
            this.threegb.TabStop = false;
            this.threegb.Enter += new System.EventHandler(this.groupBox1_Enter_1);
            // 
            // gyozteslab
            // 
            this.gyozteslab.AutoSize = true;
            this.gyozteslab.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.gyozteslab.ForeColor = System.Drawing.Color.White;
            this.gyozteslab.Location = new System.Drawing.Point(68, 208);
            this.gyozteslab.Name = "gyozteslab";
            this.gyozteslab.Size = new System.Drawing.Size(23, 23);
            this.gyozteslab.TabIndex = 39;
            this.gyozteslab.Text = "w";
            this.gyozteslab.Visible = false;
            this.gyozteslab.Click += new System.EventHandler(this.label1_Click);
            // 
            // menub
            // 
            this.menub.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.menub.ForeColor = System.Drawing.Color.Black;
            this.menub.Location = new System.Drawing.Point(27, 326);
            this.menub.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.menub.Name = "menub";
            this.menub.Size = new System.Drawing.Size(125, 62);
            this.menub.TabIndex = 38;
            this.menub.Text = "Menu";
            this.menub.UseVisualStyleBackColor = true;
            this.menub.Visible = false;
            this.menub.Click += new System.EventHandler(this.menub_Click);
            // 
            // restartb
            // 
            this.restartb.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.restartb.ForeColor = System.Drawing.Color.Black;
            this.restartb.Location = new System.Drawing.Point(27, 258);
            this.restartb.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.restartb.Name = "restartb";
            this.restartb.Size = new System.Drawing.Size(125, 62);
            this.restartb.TabIndex = 37;
            this.restartb.Text = "Restart";
            this.restartb.UseVisualStyleBackColor = true;
            this.restartb.Visible = false;
            this.restartb.Click += new System.EventHandler(this.restartb_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.ClientSize = new System.Drawing.Size(1082, 853);
            this.Controls.Add(this.threegb);
            this.Controls.Add(this.szoveg);
            this.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form2";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load_1);
            this.threegb.ResumeLayout(false);
            this.threegb.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label szoveg;
        private System.Windows.Forms.ProgressBar progressBar2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.ProgressBar progressBar3;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.ProgressBar progressBar4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox threegb;
        private System.Windows.Forms.Label gyozteslab;
        private System.Windows.Forms.Button menub;
        private System.Windows.Forms.Button restartb;
    }
}

